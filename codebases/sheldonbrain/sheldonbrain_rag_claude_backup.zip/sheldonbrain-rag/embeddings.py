"""
Sheldonbrain RAG - Embedding Generation
OpenAI embedding generation with batch support and caching.

Author: Claude (Opus 4.5) - Autonomous Development
Date: December 30, 2025
"""

import hashlib
import json
from typing import List, Optional
from pathlib import Path
from openai import OpenAI

class EmbeddingGenerator:
    """Generate embeddings using OpenAI's text-embedding models."""
    
    def __init__(self, api_key: str, model: str = "text-embedding-3-small", cache_dir: Optional[str] = None):
        self.client = OpenAI(api_key=api_key)
        self.model = model
        self.dimension = 1536  # text-embedding-3-small dimension
        
        # Optional disk cache
        self.cache_dir = Path(cache_dir) if cache_dir else None
        if self.cache_dir:
            self.cache_dir.mkdir(parents=True, exist_ok=True)
    
    def _cache_key(self, text: str) -> str:
        """Generate cache key from text hash."""
        return hashlib.md5(f"{self.model}:{text}".encode()).hexdigest()
    
    def _get_cached(self, text: str) -> Optional[List[float]]:
        """Retrieve embedding from cache if available."""
        if not self.cache_dir:
            return None
        
        cache_file = self.cache_dir / f"{self._cache_key(text)}.json"
        if cache_file.exists():
            with open(cache_file, 'r') as f:
                return json.load(f)
        return None
    
    def _set_cached(self, text: str, embedding: List[float]):
        """Store embedding in cache."""
        if not self.cache_dir:
            return
        
        cache_file = self.cache_dir / f"{self._cache_key(text)}.json"
        with open(cache_file, 'w') as f:
            json.dump(embedding, f)
    
    def embed(self, text: str) -> List[float]:
        """Generate embedding for a single text."""
        # Check cache first
        cached = self._get_cached(text)
        if cached:
            return cached
        
        # Generate embedding
        response = self.client.embeddings.create(
            model=self.model,
            input=text
        )
        embedding = response.data[0].embedding
        
        # Cache result
        self._set_cached(text, embedding)
        
        return embedding
    
    def embed_batch(self, texts: List[str], batch_size: int = 100) -> List[List[float]]:
        """Generate embeddings for multiple texts with batching."""
        all_embeddings = []
        
        for i in range(0, len(texts), batch_size):
            batch = texts[i:i + batch_size]
            
            # Check cache for each item
            batch_embeddings = []
            texts_to_embed = []
            cache_indices = []
            
            for j, text in enumerate(batch):
                cached = self._get_cached(text)
                if cached:
                    batch_embeddings.append((j, cached))
                else:
                    texts_to_embed.append(text)
                    cache_indices.append(j)
            
            # Generate embeddings for uncached texts
            if texts_to_embed:
                response = self.client.embeddings.create(
                    model=self.model,
                    input=texts_to_embed
                )
                
                for idx, (text, data) in enumerate(zip(texts_to_embed, response.data)):
                    embedding = data.embedding
                    self._set_cached(text, embedding)
                    batch_embeddings.append((cache_indices[idx], embedding))
            
            # Sort by original index and extract embeddings
            batch_embeddings.sort(key=lambda x: x[0])
            all_embeddings.extend([emb for _, emb in batch_embeddings])
        
        return all_embeddings


def create_embedding_generator(api_key: str, cache_dir: str = ".embedding_cache") -> EmbeddingGenerator:
    """Factory function to create embedding generator with caching."""
    return EmbeddingGenerator(api_key=api_key, cache_dir=cache_dir)
