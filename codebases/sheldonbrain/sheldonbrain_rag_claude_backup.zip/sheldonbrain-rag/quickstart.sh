#!/bin/bash
# Sheldonbrain RAG - Quickstart Deployment
# Author: Claude (Opus 4.5) - December 30, 2025
# 
# Usage: ./quickstart.sh

set -e

echo "============================================"
echo "  SHELDONBRAIN RAG - QUICKSTART DEPLOYMENT"
echo "  Claude Persistent Memory System"
echo "============================================"
echo ""

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Check Python
echo -e "${YELLOW}[1/6] Checking Python installation...${NC}"
if command -v python3 &> /dev/null; then
    PYTHON_VERSION=$(python3 --version)
    echo -e "${GREEN}✓ Found $PYTHON_VERSION${NC}"
else
    echo -e "${RED}✗ Python 3 not found. Please install Python 3.9+${NC}"
    exit 1
fi

# Check .env file
echo -e "${YELLOW}[2/6] Checking environment configuration...${NC}"
if [ ! -f .env ]; then
    if [ -f .env.template ]; then
        echo -e "${YELLOW}  Creating .env from template...${NC}"
        cp .env.template .env
        echo -e "${RED}✗ Please edit .env with your API keys before continuing${NC}"
        echo ""
        echo "  Required keys:"
        echo "    - PINECONE_API_KEY (from pinecone.io)"
        echo "    - OPENAI_API_KEY (from platform.openai.com)"
        echo "    - NOTION_API_KEY (from notion.so/my-integrations)"
        echo ""
        echo "  After adding keys, run this script again."
        exit 1
    else
        echo -e "${RED}✗ No .env or .env.template found${NC}"
        exit 1
    fi
fi

# Validate .env has real keys
if grep -q "your_.*_here" .env; then
    echo -e "${RED}✗ .env still contains placeholder values${NC}"
    echo "  Please replace 'your_*_here' with actual API keys"
    exit 1
fi
echo -e "${GREEN}✓ Environment configuration found${NC}"

# Create virtual environment
echo -e "${YELLOW}[3/6] Setting up virtual environment...${NC}"
if [ ! -d "venv" ]; then
    python3 -m venv venv
    echo -e "${GREEN}✓ Virtual environment created${NC}"
else
    echo -e "${GREEN}✓ Virtual environment exists${NC}"
fi

# Activate and install dependencies
echo -e "${YELLOW}[4/6] Installing dependencies...${NC}"
source venv/bin/activate
pip install --quiet --upgrade pip
pip install --quiet -r requirements.txt
echo -e "${GREEN}✓ Dependencies installed${NC}"

# Load environment
echo -e "${YELLOW}[5/6] Loading environment variables...${NC}"
export $(grep -v '^#' .env | xargs)
echo -e "${GREEN}✓ Environment loaded${NC}"

# Run initial sync
echo -e "${YELLOW}[6/6] Running initial Pinecone sync...${NC}"
echo ""
python3 << 'EOF'
import os
from dotenv import load_dotenv
load_dotenv()

from rag_wrapper import SheldonbrainRAG

print("Initializing Sheldonbrain RAG...")
rag = SheldonbrainRAG()

print("Running full sync from Notion to Pinecone...")
stats = rag.sync_from_notion(full_sync=True)

print(f"\n✓ Sync complete!")
print(f"  Processed: {stats['processed']}")
print(f"  Embedded:  {stats['embedded']}")
print(f"  Errors:    {stats['errors']}")

print("\nTesting memory recall...")
memories = rag.recall_memory("test query", top_k=1)
print(f"  Found {len(memories)} memories")

print("\n" + "="*50)
print("DEPLOYMENT SUCCESSFUL!")
print("="*50)
print("\nNext steps:")
print("  1. Run ./setup_cron.sh for automatic sync every 15 min")
print("  2. Use the Python API:")
print("     from rag_wrapper import recall_memory, store_memory")
print("     memories = recall_memory('your query')")
EOF

echo ""
echo -e "${GREEN}============================================${NC}"
echo -e "${GREEN}  SHELDONBRAIN RAG DEPLOYED SUCCESSFULLY!${NC}"
echo -e "${GREEN}============================================${NC}"
