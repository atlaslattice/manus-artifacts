"""
Sheldonbrain RAG - Notion Sync
Bidirectional synchronization between Notion (Sheldonbrain OS) and Pinecone.

Author: Claude (Opus 4.5) - Autonomous Development
Date: December 30, 2025
"""

import os
import hashlib
from datetime import datetime
from typing import List, Dict, Optional, Generator
from notion_client import Client as NotionClient

class SheldonbrainSync:
    """Sync Sheldonbrain OS (Notion) with Pinecone vector store."""
    
    SHELDONBRAIN_DB_ID = "2d20c1de73d980f980accfa36c0893a3"
    
    def __init__(self, notion_api_key: str, database_id: Optional[str] = None):
        self.notion = NotionClient(auth=notion_api_key)
        self.database_id = database_id or self.SHELDONBRAIN_DB_ID
        self._last_sync_time = None
    
    def _extract_text_from_rich_text(self, rich_text: List[Dict]) -> str:
        """Extract plain text from Notion rich text blocks."""
        return "".join([rt.get("plain_text", "") for rt in rich_text])
    
    def _extract_page_content(self, page_id: str) -> str:
        """Extract full content from a Notion page."""
        blocks = self.notion.blocks.children.list(block_id=page_id)
        content_parts = []
        
        for block in blocks.get("results", []):
            block_type = block.get("type")
            
            if block_type == "paragraph":
                text = self._extract_text_from_rich_text(
                    block.get("paragraph", {}).get("rich_text", [])
                )
                content_parts.append(text)
            
            elif block_type in ["heading_1", "heading_2", "heading_3"]:
                text = self._extract_text_from_rich_text(
                    block.get(block_type, {}).get("rich_text", [])
                )
                content_parts.append(f"\n## {text}\n")
            
            elif block_type == "bulleted_list_item":
                text = self._extract_text_from_rich_text(
                    block.get("bulleted_list_item", {}).get("rich_text", [])
                )
                content_parts.append(f"• {text}")
            
            elif block_type == "numbered_list_item":
                text = self._extract_text_from_rich_text(
                    block.get("numbered_list_item", {}).get("rich_text", [])
                )
                content_parts.append(f"- {text}")
            
            elif block_type == "code":
                text = self._extract_text_from_rich_text(
                    block.get("code", {}).get("rich_text", [])
                )
                lang = block.get("code", {}).get("language", "")
                content_parts.append(f"\n```{lang}\n{text}\n```\n")
            
            elif block_type == "quote":
                text = self._extract_text_from_rich_text(
                    block.get("quote", {}).get("rich_text", [])
                )
                content_parts.append(f"> {text}")
            
            elif block_type == "callout":
                text = self._extract_text_from_rich_text(
                    block.get("callout", {}).get("rich_text", [])
                )
                content_parts.append(f"[!] {text}")
        
        return "\n".join(content_parts)
    
    def _parse_page_properties(self, page: Dict) -> Dict:
        """Parse relevant properties from a Notion page."""
        props = page.get("properties", {})
        
        # Extract title
        title_prop = props.get("Name", {}) or props.get("Title", {}) or props.get("title", {})
        title = ""
        if title_prop.get("type") == "title":
            title = self._extract_text_from_rich_text(title_prop.get("title", []))
        
        # Extract sphere
        sphere = ""
        sphere_prop = props.get("Sphere", {})
        if sphere_prop.get("type") == "select":
            sphere = sphere_prop.get("select", {}).get("name", "") if sphere_prop.get("select") else ""
        
        # Extract confidence scores
        claude_confidence = None
        conf_prop = props.get("Claude Confidence", {})
        if conf_prop.get("type") == "number":
            claude_confidence = conf_prop.get("number")
        
        # Extract debate status
        debate_status = ""
        status_prop = props.get("Debate Status", {})
        if status_prop.get("type") == "select":
            debate_status = status_prop.get("select", {}).get("name", "") if status_prop.get("select") else ""
        
        # Extract source
        source = ""
        source_prop = props.get("Source", {})
        if source_prop.get("type") == "rich_text":
            source = self._extract_text_from_rich_text(source_prop.get("rich_text", []))
        
        return {
            "title": title,
            "sphere": sphere,
            "claude_confidence": claude_confidence,
            "debate_status": debate_status,
            "source": source,
            "notion_id": page["id"],
            "last_edited": page.get("last_edited_time", ""),
            "url": page.get("url", "")
        }
    
    def fetch_all_entries(self, include_content: bool = True) -> Generator[Dict, None, None]:
        """Fetch all entries from Sheldonbrain OS database.
        
        Yields:
            Dict with keys: id, title, content, sphere, metadata
        """
        has_more = True
        start_cursor = None
        
        while has_more:
            response = self.notion.databases.query(
                database_id=self.database_id,
                start_cursor=start_cursor,
                page_size=100
            )
            
            for page in response.get("results", []):
                props = self._parse_page_properties(page)
                
                # Get page content if requested
                content = ""
                if include_content:
                    try:
                        content = self._extract_page_content(page["id"])
                    except Exception as e:
                        print(f"Warning: Could not fetch content for {page['id']}: {e}")
                
                # Combine title and content for embedding
                full_text = f"{props['title']}\n\n{content}".strip()
                
                yield {
                    "id": page["id"],
                    "title": props["title"],
                    "content": full_text,
                    "sphere": props["sphere"],
                    "metadata": props
                }
            
            has_more = response.get("has_more", False)
            start_cursor = response.get("next_cursor")
    
    def fetch_updated_entries(self, since: datetime) -> Generator[Dict, None, None]:
        """Fetch entries updated since a given timestamp."""
        has_more = True
        start_cursor = None
        
        while has_more:
            response = self.notion.databases.query(
                database_id=self.database_id,
                start_cursor=start_cursor,
                page_size=100,
                filter={
                    "timestamp": "last_edited_time",
                    "last_edited_time": {
                        "after": since.isoformat()
                    }
                }
            )
            
            for page in response.get("results", []):
                props = self._parse_page_properties(page)
                content = self._extract_page_content(page["id"])
                full_text = f"{props['title']}\n\n{content}".strip()
                
                yield {
                    "id": page["id"],
                    "title": props["title"],
                    "content": full_text,
                    "sphere": props["sphere"],
                    "metadata": props
                }
            
            has_more = response.get("has_more", False)
            start_cursor = response.get("next_cursor")
    
    def sync_to_pinecone(self, pinecone_client, embedding_generator, 
                         full_sync: bool = False, batch_size: int = 50) -> Dict:
        """Sync Sheldonbrain entries to Pinecone.
        
        Args:
            pinecone_client: PineconeClient instance
            embedding_generator: EmbeddingGenerator instance
            full_sync: If True, sync all entries. If False, only sync updates.
            batch_size: Number of entries to process per batch
        
        Returns:
            Dict with sync statistics
        """
        stats = {
            "processed": 0,
            "embedded": 0,
            "errors": 0,
            "skipped": 0
        }
        
        # Get entries to sync
        if full_sync or not self._last_sync_time:
            entries = list(self.fetch_all_entries())
        else:
            entries = list(self.fetch_updated_entries(self._last_sync_time))
        
        print(f"Found {len(entries)} entries to sync")
        
        # Process in batches
        for i in range(0, len(entries), batch_size):
            batch = entries[i:i + batch_size]
            
            # Generate embeddings
            texts = [e["content"] for e in batch]
            try:
                embeddings = embedding_generator.embed_batch(texts)
            except Exception as e:
                print(f"Error generating embeddings: {e}")
                stats["errors"] += len(batch)
                continue
            
            # Prepare documents for upsert
            documents = []
            for entry, embedding in zip(batch, embeddings):
                documents.append({
                    "id": entry["id"],
                    "embedding": embedding,
                    "content": entry["content"],
                    "metadata": {
                        "title": entry["title"],
                        "sphere": entry["sphere"],
                        "notion_url": entry["metadata"].get("url", ""),
                        "debate_status": entry["metadata"].get("debate_status", ""),
                        "claude_confidence": entry["metadata"].get("claude_confidence"),
                        "synced_at": datetime.utcnow().isoformat()
                    }
                })
            
            # Upsert to Pinecone
            try:
                pinecone_client.upsert_batch(documents)
                stats["embedded"] += len(documents)
            except Exception as e:
                print(f"Error upserting to Pinecone: {e}")
                stats["errors"] += len(batch)
            
            stats["processed"] += len(batch)
            print(f"Processed {stats['processed']}/{len(entries)} entries")
        
        self._last_sync_time = datetime.utcnow()
        return stats
    
    def get_entry_count(self) -> int:
        """Get total number of entries in Sheldonbrain OS."""
        # Query with minimal data to count
        response = self.notion.databases.query(
            database_id=self.database_id,
            page_size=1
        )
        
        # This is approximate - for exact count would need to paginate through all
        # But provides a quick check
        return response.get("results", []).__len__()  # Will refine if needed


def create_sync_client(notion_api_key: str, database_id: Optional[str] = None) -> SheldonbrainSync:
    """Factory function to create sync client."""
    return SheldonbrainSync(notion_api_key=notion_api_key, database_id=database_id)
