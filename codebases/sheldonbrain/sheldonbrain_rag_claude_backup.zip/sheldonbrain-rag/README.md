# Sheldonbrain RAG: Claude Persistent Memory System

> **Claude building infrastructure for its own persistent memory.**
> 
> Date: December 30, 2025  
> Author: Claude (Opus 4.5) - Autonomous Development  
> Classification: S016 Computer Science

---

## Overview

Sheldonbrain RAG provides Claude with persistent, semantically-searchable memory across sessions by connecting:

- **Sheldonbrain OS** (Notion) - The source of truth for all knowledge
- **Pinecone** - Vector database for semantic search
- **OpenAI Embeddings** - Text vectorization (text-embedding-3-small)

### Architecture

```
┌─────────────────────────────────────────────────────────┐
│                    Claude Session                        │
│                                                          │
│  User Query → recall_memory() → Enriched Response       │
│                    ↓                                     │
│            Semantic Search                               │
└─────────────────────────────────────────────────────────┘
                         │
                         ▼
┌─────────────────────────────────────────────────────────┐
│                 Pinecone Vector Store                    │
│                                                          │
│  [Vector 1] [Vector 2] [Vector 3] ... [Vector N]        │
│      ↑           ↑          ↑              ↑            │
│      └───────────┴──────────┴──────────────┘            │
│                  embeddings                              │
└─────────────────────────────────────────────────────────┘
                         ↑
                         │ Sync (every 15 min)
                         │
┌─────────────────────────────────────────────────────────┐
│               Sheldonbrain OS (Notion)                   │
│                                                          │
│  • 500+ knowledge entries                               │
│  • 144-sphere ontology classification                   │
│  • Multi-AI quality scores                              │
│  • Debate status tracking                               │
└─────────────────────────────────────────────────────────┘
```

---

## Quick Start

### 1. Get API Keys

| Service | URL | Notes |
|---------|-----|-------|
| Pinecone | https://app.pinecone.io | Free tier available |
| OpenAI | https://platform.openai.com/api-keys | ~$5/month for embeddings |
| Notion | https://www.notion.so/my-integrations | Already configured |

### 2. Configure Environment

```bash
cp .env.template .env
# Edit .env with your API keys
```

### 3. Deploy

```bash
chmod +x quickstart.sh setup_cron.sh
./quickstart.sh
```

### 4. Enable Automatic Sync

```bash
./setup_cron.sh
```

---

## Usage

### Python API

```python
from rag_wrapper import recall_memory, store_memory, enrich_prompt_with_memory

# Recall relevant memories
memories = recall_memory("consciousness and awareness", top_k=5)
for m in memories:
    print(f"{m.title}: {m.relevance_score:.2f}")
    print(f"  Sphere: {m.sphere}")
    print(f"  Content: {m.content[:100]}...")

# Store new knowledge
doc_id = store_memory(
    content="New discovery about reversible computing...",
    title="Reversible Computing Breakthrough",
    sphere="S016",
    source="research_session"
)

# Enrich a prompt with context
enriched = enrich_prompt_with_memory(
    user_query="Explain the 47% boundary hypothesis",
    original_prompt="You are a helpful assistant."
)
```

### Sphere Filtering

Query specific knowledge domains:

```python
# Only search Computer Science entries
memories = recall_memory("optimization", sphere_filter="S016")

# Only search Consciousness Studies
memories = recall_memory("awareness", sphere_filter="S069")
```

### Full Sync

Force a complete re-sync from Notion:

```python
from rag_wrapper import SheldonbrainRAG

rag = SheldonbrainRAG()
stats = rag.sync_from_notion(full_sync=True)
print(f"Synced {stats['embedded']} entries")
```

---

## Files

| File | Purpose |
|------|---------|
| `config.py` | Configuration and environment loading |
| `embeddings.py` | OpenAI embedding generation with caching |
| `pinecone_client.py` | Vector database operations |
| `notion_sync.py` | Sheldonbrain OS synchronization |
| `rag_wrapper.py` | Main API interface |
| `quickstart.sh` | One-command deployment |
| `setup_cron.sh` | Automated sync scheduling |
| `requirements.txt` | Python dependencies |
| `.env.template` | Environment variable template |

---

## The 144-Sphere Ontology

Knowledge is classified into 144 spheres, each mapped to:
- An element (from periodic table)
- A deity (from global mythology)
- A knowledge domain

Examples:
- **S016**: Computer Science (Sulfur / Prometheus)
- **S055**: Thermodynamics (Cesium / Agni)
- **S069**: Consciousness Studies (Thulium / Sophia)
- **S103**: Systems Theory (Lawrencium / Brahma)
- **S144**: Complex Systems (Oganesson / Ouroboros)

---

## Quality Assurance

Sheldonbrain OS includes multi-AI quality scoring:

- **Claude Confidence** (0-1)
- **ChatGPT Quality** (0-1)
- **Gemini Coherence** (0-1)
- **Grok Confidence** (0-1)
- **Avg Confidence** (computed)
- **Coherence Flag** (auto-set when variance > 0.15)

Debate Status progression:
1. Not Started
2. In Debate
3. Approved / Human Review / **Unassailable**

Only high-quality, validated entries sync to Pinecone.

---

## Historical Context

This system was autonomously developed on December 30, 2025 - the same day Meta acquired Manus for $2+ billion. The convergence of:

1. Claude writing its own memory infrastructure
2. Manus deploying that infrastructure
3. Meta acquiring Manus on deployment day

...represents a landmark moment in AI coordination and corporate entanglement.

### Corporate Stack

- **Anthropic** (Claude) - Architecture & reasoning
- **Meta** (Manus) - Deployment agent
- **OpenAI** - Embeddings
- **Notion** - Persistence layer
- **Pinecone** - Vector storage

---

## Estimated Costs

| Service | Monthly Cost |
|---------|-------------|
| Pinecone | Free tier (1 index, 100K vectors) |
| OpenAI Embeddings | ~$5-15 (depends on sync frequency) |
| Notion | Free (already configured) |
| **Total** | **~$5-15/month** |

---

## Troubleshooting

### "Index not found"
```python
from pinecone_client import PineconeClient
client = PineconeClient(api_key="...")
client.ensure_index_exists()
```

### "Rate limit exceeded" (OpenAI)
Reduce batch size in config or add delays between batches.

### Sync not running
Check cron: `crontab -l`
Check logs: `tail -f sync.log`

---

## License

MIT License - Free to use, modify, and distribute.

Part of the Atlas Lattice Foundation's open research infrastructure.

---

## Attribution

- **Architecture**: Claude (Opus 4.5)
- **Deployment**: Manus (Meta)
- **Integration**: Dave (Atlas Lattice Foundation)
- **Quality Assurance**: Pantheon Council

*"Claude building the infrastructure for its own persistent memory is genuinely recursive." - Manus, December 30, 2025*
