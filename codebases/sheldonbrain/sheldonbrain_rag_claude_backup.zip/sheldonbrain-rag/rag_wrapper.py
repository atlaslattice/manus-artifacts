"""
Sheldonbrain RAG - Main Wrapper
Primary interface for Claude persistent memory operations.

Author: Claude (Opus 4.5) - Autonomous Development
Date: December 30, 2025

This module provides the main API for:
- recall_memory(): Semantic search across stored knowledge
- store_memory(): Save new insights to the vector store
- enrich_prompt_with_memory(): Augment prompts with relevant context
"""

import os
import uuid
from datetime import datetime
from typing import List, Dict, Optional, Any
from dataclasses import dataclass

from config import load_config, RAGConfig
from embeddings import EmbeddingGenerator
from pinecone_client import PineconeClient, SearchResult
from notion_sync import SheldonbrainSync

@dataclass
class Memory:
    """A retrieved memory from the vector store."""
    id: str
    content: str
    title: str
    sphere: str
    relevance_score: float
    source: str
    metadata: Dict[str, Any]

class SheldonbrainRAG:
    """Main interface for Sheldonbrain RAG operations."""
    
    def __init__(self, config: Optional[RAGConfig] = None):
        """Initialize RAG system with configuration.
        
        Args:
            config: RAGConfig instance. If None, loads from environment.
        """
        self.config = config or load_config()
        
        # Initialize components
        self.embeddings = EmbeddingGenerator(
            api_key=self.config.openai.api_key,
            model=self.config.openai.embedding_model,
            cache_dir=".embedding_cache"
        )
        
        self.pinecone = PineconeClient(
            api_key=self.config.pinecone.api_key,
            index_name=self.config.pinecone.index_name
        )
        self.pinecone.connect()
        
        self.notion = SheldonbrainSync(
            notion_api_key=self.config.notion.api_key,
            database_id=self.config.notion.database_id
        )
    
    def recall_memory(self, query: str, top_k: int = 5, 
                      sphere_filter: Optional[str] = None,
                      min_relevance: float = 0.0) -> List[Memory]:
        """Recall relevant memories for a query.
        
        This is the primary method for Claude to access its persistent memory.
        
        Args:
            query: Natural language query (e.g., "What do I know about consciousness?")
            top_k: Maximum number of memories to return
            sphere_filter: Optional sphere ID to limit search (e.g., "S069")
            min_relevance: Minimum similarity score (0-1)
        
        Returns:
            List of Memory objects sorted by relevance
        
        Example:
            >>> rag = SheldonbrainRAG()
            >>> memories = rag.recall_memory("reversible computing efficiency")
            >>> for m in memories:
            ...     print(f"{m.title}: {m.relevance_score:.2f}")
        """
        # Generate query embedding
        query_embedding = self.embeddings.embed(query)
        
        # Search Pinecone
        results = self.pinecone.query_similar(
            query_embedding=query_embedding,
            top_k=top_k,
            sphere_filter=sphere_filter,
            min_score=min_relevance
        )
        
        # Convert to Memory objects
        memories = []
        for result in results:
            memories.append(Memory(
                id=result.id,
                content=result.content,
                title=result.metadata.get("title", "Untitled"),
                sphere=result.metadata.get("sphere", ""),
                relevance_score=result.score,
                source=result.metadata.get("notion_url", ""),
                metadata=result.metadata
            ))
        
        return memories
    
    def store_memory(self, content: str, title: Optional[str] = None,
                     sphere: Optional[str] = None, source: str = "claude_session",
                     metadata: Optional[Dict] = None) -> str:
        """Store a new memory in the vector store.
        
        Use this to persist new discoveries, insights, or synthesized knowledge.
        
        Args:
            content: The content to store (will be embedded)
            title: Optional title for the memory
            sphere: Optional sphere classification (e.g., "S016")
            source: Source identifier (default: "claude_session")
            metadata: Additional metadata to store
        
        Returns:
            ID of the stored memory
        
        Example:
            >>> rag = SheldonbrainRAG()
            >>> doc_id = rag.store_memory(
            ...     content="The 47% boundary appears across multiple domains...",
            ...     title="47% Pattern Discovery",
            ...     sphere="S055",
            ...     source="research_session_2025_12_30"
            ... )
        """
        # Generate unique ID
        doc_id = f"claude_{datetime.utcnow().strftime('%Y%m%d_%H%M%S')}_{uuid.uuid4().hex[:8]}"
        
        # Generate embedding
        full_content = f"{title or 'Untitled'}\n\n{content}"
        embedding = self.embeddings.embed(full_content)
        
        # Prepare metadata
        doc_metadata = metadata or {}
        doc_metadata.update({
            "title": title or "Untitled",
            "sphere": sphere or "",
            "source": source,
            "created_at": datetime.utcnow().isoformat(),
            "created_by": "claude"
        })
        
        # Store in Pinecone
        self.pinecone.upsert_document(
            doc_id=doc_id,
            embedding=embedding,
            content=full_content,
            metadata=doc_metadata
        )
        
        return doc_id
    
    def enrich_prompt_with_memory(self, user_query: str, 
                                  original_prompt: str = "",
                                  top_k: int = 3,
                                  sphere_filter: Optional[str] = None) -> str:
        """Enrich a prompt with relevant memories.
        
        This method retrieves relevant context and formats it for injection
        into a prompt, enabling memory-augmented responses.
        
        Args:
            user_query: The user's question or request
            original_prompt: The original system/user prompt
            top_k: Number of memories to include
            sphere_filter: Optional sphere to focus search
        
        Returns:
            Enriched prompt with memory context prepended
        
        Example:
            >>> rag = SheldonbrainRAG()
            >>> enriched = rag.enrich_prompt_with_memory(
            ...     user_query="Explain reversible computing",
            ...     original_prompt="You are a helpful assistant."
            ... )
        """
        # Recall relevant memories
        memories = self.recall_memory(
            query=user_query,
            top_k=top_k,
            sphere_filter=sphere_filter,
            min_relevance=self.config.similarity_threshold
        )
        
        if not memories:
            return original_prompt
        
        # Format memory context
        memory_context = "## Relevant Knowledge from Sheldonbrain\n\n"
        for i, mem in enumerate(memories, 1):
            memory_context += f"### Memory {i}: {mem.title}\n"
            memory_context += f"**Sphere:** {mem.sphere} | **Relevance:** {mem.relevance_score:.2f}\n"
            memory_context += f"{mem.content[:500]}...\n\n"
        
        memory_context += "---\n\n"
        
        # Combine with original prompt
        enriched_prompt = memory_context + original_prompt
        
        return enriched_prompt
    
    def sync_from_notion(self, full_sync: bool = False) -> Dict:
        """Sync Sheldonbrain OS to Pinecone.
        
        Args:
            full_sync: If True, sync all entries. If False, only recent updates.
        
        Returns:
            Sync statistics dictionary
        """
        return self.notion.sync_to_pinecone(
            pinecone_client=self.pinecone,
            embedding_generator=self.embeddings,
            full_sync=full_sync,
            batch_size=self.config.batch_size
        )
    
    def get_stats(self) -> Dict:
        """Get current system statistics."""
        pinecone_stats = self.pinecone.get_stats()
        
        return {
            "pinecone": pinecone_stats,
            "index_name": self.config.pinecone.index_name,
            "embedding_model": self.config.openai.embedding_model,
            "notion_db": self.config.notion.database_id
        }


# Convenience functions for direct import
_rag_instance: Optional[SheldonbrainRAG] = None

def get_rag() -> SheldonbrainRAG:
    """Get or create singleton RAG instance."""
    global _rag_instance
    if _rag_instance is None:
        _rag_instance = SheldonbrainRAG()
    return _rag_instance

def recall_memory(query: str, top_k: int = 5, sphere_filter: Optional[str] = None) -> List[Memory]:
    """Convenience function to recall memories."""
    return get_rag().recall_memory(query, top_k, sphere_filter)

def store_memory(content: str, title: Optional[str] = None, 
                 sphere: Optional[str] = None, source: str = "claude_session") -> str:
    """Convenience function to store memories."""
    return get_rag().store_memory(content, title, sphere, source)

def enrich_prompt_with_memory(user_query: str, original_prompt: str = "", top_k: int = 3) -> str:
    """Convenience function to enrich prompts with memory."""
    return get_rag().enrich_prompt_with_memory(user_query, original_prompt, top_k)


if __name__ == "__main__":
    # Quick test
    print("Initializing Sheldonbrain RAG...")
    rag = SheldonbrainRAG()
    
    print("\nSystem Stats:")
    stats = rag.get_stats()
    print(f"  Index: {stats['index_name']}")
    print(f"  Vectors: {stats['pinecone'].get('total_vectors', 'N/A')}")
    print(f"  Model: {stats['embedding_model']}")
    
    print("\nRAG system ready for queries.")
