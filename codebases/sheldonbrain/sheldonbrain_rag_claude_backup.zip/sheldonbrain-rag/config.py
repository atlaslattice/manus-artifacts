"""
Sheldonbrain RAG Configuration
Configuration and environment variables for Claude persistent memory system.

Author: Claude (Opus 4.5) - Autonomous Development
Date: December 30, 2025
Classification: S016 Computer Science
"""

import os
from dataclasses import dataclass
from typing import Optional

@dataclass
class PineconeConfig:
    """Pinecone vector database configuration."""
    api_key: str
    environment: str = "us-east-1-aws"
    index_name: str = "sheldonbrain-rag"
    dimension: int = 1536  # text-embedding-3-small
    metric: str = "cosine"
    
@dataclass
class OpenAIConfig:
    """OpenAI API configuration for embeddings."""
    api_key: str
    embedding_model: str = "text-embedding-3-small"
    
@dataclass
class NotionConfig:
    """Notion API configuration for Sheldonbrain OS access."""
    api_key: str
    database_id: str = "2d20c1de73d980f980accfa36c0893a3"  # Sheldonbrain OS
    
@dataclass
class RAGConfig:
    """Main RAG system configuration."""
    pinecone: PineconeConfig
    openai: OpenAIConfig
    notion: NotionConfig
    
    # RAG parameters
    top_k: int = 5
    similarity_threshold: float = 0.7
    chunk_size: int = 1000
    chunk_overlap: int = 200
    
    # Sync settings
    sync_interval_minutes: int = 15
    batch_size: int = 100

def load_config() -> RAGConfig:
    """Load configuration from environment variables."""
    
    # Validate required environment variables
    required_vars = ["PINECONE_API_KEY", "OPENAI_API_KEY", "NOTION_API_KEY"]
    missing = [var for var in required_vars if not os.getenv(var)]
    
    if missing:
        raise ValueError(f"Missing required environment variables: {', '.join(missing)}")
    
    return RAGConfig(
        pinecone=PineconeConfig(
            api_key=os.getenv("PINECONE_API_KEY"),
            environment=os.getenv("PINECONE_ENVIRONMENT", "us-east-1-aws"),
            index_name=os.getenv("PINECONE_INDEX", "sheldonbrain-rag"),
        ),
        openai=OpenAIConfig(
            api_key=os.getenv("OPENAI_API_KEY"),
            embedding_model=os.getenv("EMBEDDING_MODEL", "text-embedding-3-small"),
        ),
        notion=NotionConfig(
            api_key=os.getenv("NOTION_API_KEY"),
            database_id=os.getenv("SHELDONBRAIN_DB_ID", "2d20c1de73d980f980accfa36c0893a3"),
        ),
        top_k=int(os.getenv("RAG_TOP_K", "5")),
        similarity_threshold=float(os.getenv("RAG_THRESHOLD", "0.7")),
        sync_interval_minutes=int(os.getenv("SYNC_INTERVAL", "15")),
    )

# Sphere ID to Name mapping (subset - full 144 available)
SPHERE_NAMES = {
    "S001": "Quantum Physics",
    "S016": "Computer Science", 
    "S055": "Thermodynamics",
    "S069": "Consciousness Studies",
    "S103": "Systems Theory",
    "S144": "Complex Systems",
    # ... extend as needed
}

def get_sphere_name(sphere_id: str) -> str:
    """Get human-readable sphere name from ID."""
    return SPHERE_NAMES.get(sphere_id, f"Sphere {sphere_id}")
