#!/bin/bash
# Sheldonbrain RAG - Cron Setup for Automated Sync
# Author: Claude (Opus 4.5) - December 30, 2025
#
# Sets up a cron job to sync Notion → Pinecone every 15 minutes

set -e

echo "============================================"
echo "  SHELDONBRAIN RAG - CRON SETUP"
echo "============================================"
echo ""

# Get absolute path
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SYNC_SCRIPT="$SCRIPT_DIR/sync_job.py"
PYTHON_PATH="$SCRIPT_DIR/venv/bin/python3"
LOG_FILE="$SCRIPT_DIR/sync.log"

# Create sync job script
echo "Creating sync job script..."
cat > "$SYNC_SCRIPT" << 'SYNCEOF'
#!/usr/bin/env python3
"""
Sheldonbrain RAG - Sync Job
Runs as cron job to sync Notion to Pinecone.
"""
import os
import sys
from datetime import datetime
from pathlib import Path

# Add project to path
project_dir = Path(__file__).parent
sys.path.insert(0, str(project_dir))
os.chdir(project_dir)

# Load environment
from dotenv import load_dotenv
load_dotenv()

from rag_wrapper import SheldonbrainRAG

def main():
    timestamp = datetime.now().isoformat()
    print(f"\n[{timestamp}] Starting Sheldonbrain sync...")
    
    try:
        rag = SheldonbrainRAG()
        stats = rag.sync_from_notion(full_sync=False)
        
        print(f"[{timestamp}] Sync complete: {stats['processed']} processed, {stats['embedded']} embedded")
        return 0
    except Exception as e:
        print(f"[{timestamp}] Sync failed: {e}")
        return 1

if __name__ == "__main__":
    sys.exit(main())
SYNCEOF

chmod +x "$SYNC_SCRIPT"
echo "✓ Sync script created at: $SYNC_SCRIPT"

# Create the cron entry
CRON_ENTRY="*/15 * * * * cd $SCRIPT_DIR && $PYTHON_PATH $SYNC_SCRIPT >> $LOG_FILE 2>&1"

echo ""
echo "Proposed cron entry:"
echo "  $CRON_ENTRY"
echo ""

# Check if cron job already exists
EXISTING=$(crontab -l 2>/dev/null | grep -F "sheldonbrain-rag" || true)

if [ -n "$EXISTING" ]; then
    echo "⚠ Existing Sheldonbrain cron job found:"
    echo "  $EXISTING"
    echo ""
    read -p "Replace existing job? (y/n): " REPLACE
    if [ "$REPLACE" != "y" ]; then
        echo "Cancelled."
        exit 0
    fi
    # Remove existing
    crontab -l 2>/dev/null | grep -vF "sheldonbrain-rag" | crontab - || true
fi

# Add new cron job
(crontab -l 2>/dev/null; echo "# Sheldonbrain RAG sync every 15 minutes"; echo "$CRON_ENTRY") | crontab -

echo ""
echo "✓ Cron job installed!"
echo ""
echo "Current crontab:"
crontab -l | grep -A1 "Sheldonbrain"
echo ""
echo "============================================"
echo "  AUTOMATED SYNC ENABLED"
echo "============================================"
echo ""
echo "The system will now:"
echo "  • Check Notion for updates every 15 minutes"
echo "  • Sync new/modified entries to Pinecone"
echo "  • Log activity to: $LOG_FILE"
echo ""
echo "To view logs: tail -f $LOG_FILE"
echo "To disable:   crontab -e (and remove the line)"
