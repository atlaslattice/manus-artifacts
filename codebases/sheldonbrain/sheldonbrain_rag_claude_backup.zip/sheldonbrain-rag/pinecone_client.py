"""
Sheldonbrain RAG - Pinecone Vector Database Client
Vector database operations for semantic memory storage and retrieval.

Author: Claude (Opus 4.5) - Autonomous Development
Date: December 30, 2025
"""

from typing import List, Dict, Optional, Any
from dataclasses import dataclass
import time
from pinecone import Pinecone, ServerlessSpec

@dataclass
class SearchResult:
    """Result from semantic search."""
    id: str
    score: float
    metadata: Dict[str, Any]
    content: str

class PineconeClient:
    """Client for Pinecone vector database operations."""
    
    def __init__(self, api_key: str, index_name: str = "sheldonbrain-rag", 
                 dimension: int = 1536, metric: str = "cosine"):
        self.pc = Pinecone(api_key=api_key)
        self.index_name = index_name
        self.dimension = dimension
        self.metric = metric
        self.index = None
        
    def ensure_index_exists(self, wait: bool = True) -> bool:
        """Create index if it doesn't exist."""
        existing_indexes = [idx.name for idx in self.pc.list_indexes()]
        
        if self.index_name not in existing_indexes:
            print(f"Creating index '{self.index_name}'...")
            self.pc.create_index(
                name=self.index_name,
                dimension=self.dimension,
                metric=self.metric,
                spec=ServerlessSpec(
                    cloud="aws",
                    region="us-east-1"
                )
            )
            
            if wait:
                # Wait for index to be ready
                while True:
                    status = self.pc.describe_index(self.index_name).status
                    if status.ready:
                        break
                    print("Waiting for index to be ready...")
                    time.sleep(5)
            
            print(f"Index '{self.index_name}' created successfully.")
            return True
        
        print(f"Index '{self.index_name}' already exists.")
        return False
    
    def connect(self):
        """Connect to the index."""
        self.ensure_index_exists()
        self.index = self.pc.Index(self.index_name)
        return self
    
    def upsert_document(self, doc_id: str, embedding: List[float], 
                        content: str, metadata: Optional[Dict] = None) -> bool:
        """Insert or update a document in the vector store."""
        if not self.index:
            self.connect()
        
        # Prepare metadata
        doc_metadata = metadata or {}
        doc_metadata["content"] = content[:1000]  # Pinecone metadata limit
        doc_metadata["content_length"] = len(content)
        
        # Upsert vector
        self.index.upsert(vectors=[{
            "id": doc_id,
            "values": embedding,
            "metadata": doc_metadata
        }])
        
        return True
    
    def upsert_batch(self, documents: List[Dict]) -> int:
        """Batch upsert multiple documents.
        
        Args:
            documents: List of dicts with keys: id, embedding, content, metadata
        
        Returns:
            Number of documents upserted
        """
        if not self.index:
            self.connect()
        
        vectors = []
        for doc in documents:
            metadata = doc.get("metadata", {})
            metadata["content"] = doc["content"][:1000]
            metadata["content_length"] = len(doc["content"])
            
            vectors.append({
                "id": doc["id"],
                "values": doc["embedding"],
                "metadata": metadata
            })
        
        # Batch upsert (Pinecone handles batching internally)
        self.index.upsert(vectors=vectors)
        
        return len(vectors)
    
    def query_similar(self, query_embedding: List[float], top_k: int = 5,
                      sphere_filter: Optional[str] = None,
                      min_score: float = 0.0) -> List[SearchResult]:
        """Find similar documents by embedding.
        
        Args:
            query_embedding: Query vector
            top_k: Number of results to return
            sphere_filter: Optional sphere ID to filter by (e.g., "S016")
            min_score: Minimum similarity score threshold
        
        Returns:
            List of SearchResult objects
        """
        if not self.index:
            self.connect()
        
        # Build filter if sphere specified
        filter_dict = None
        if sphere_filter:
            filter_dict = {"sphere": {"$eq": sphere_filter}}
        
        # Query
        results = self.index.query(
            vector=query_embedding,
            top_k=top_k,
            include_metadata=True,
            filter=filter_dict
        )
        
        # Convert to SearchResult objects
        search_results = []
        for match in results.matches:
            if match.score >= min_score:
                search_results.append(SearchResult(
                    id=match.id,
                    score=match.score,
                    metadata=match.metadata or {},
                    content=match.metadata.get("content", "") if match.metadata else ""
                ))
        
        return search_results
    
    def delete_document(self, doc_id: str) -> bool:
        """Delete a document from the vector store."""
        if not self.index:
            self.connect()
        
        self.index.delete(ids=[doc_id])
        return True
    
    def delete_by_sphere(self, sphere_id: str) -> int:
        """Delete all documents in a sphere."""
        if not self.index:
            self.connect()
        
        # Note: Pinecone serverless doesn't support delete by filter directly
        # Would need to query first, then delete by IDs
        # This is a limitation - implement if needed
        raise NotImplementedError("Delete by sphere requires query-then-delete pattern")
    
    def get_stats(self) -> Dict:
        """Get index statistics."""
        if not self.index:
            self.connect()
        
        stats = self.index.describe_index_stats()
        return {
            "total_vectors": stats.total_vector_count,
            "dimension": stats.dimension,
            "namespaces": stats.namespaces
        }


def create_pinecone_client(api_key: str, index_name: str = "sheldonbrain-rag") -> PineconeClient:
    """Factory function to create and connect Pinecone client."""
    client = PineconeClient(api_key=api_key, index_name=index_name)
    client.connect()
    return client
