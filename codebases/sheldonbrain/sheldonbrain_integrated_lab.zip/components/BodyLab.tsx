import React, { useRef, useState } from 'react';
import { ParseResult } from '../types';
import { Icons } from '../constants';

interface Props {
  files: ParseResult[];
  setFiles: React.Dispatch<React.SetStateAction<ParseResult[]>>;
}

const BodyLab: React.FC<Props> = ({ files, setFiles }) => {
  const [isParsing, setIsParsing] = useState(false);
  const [isIndexing, setIsIndexing] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const uploadedFiles = e.target.files;
    if (!uploadedFiles) return;

    setIsParsing(true);
    
    setTimeout(() => {
      Array.from(uploadedFiles).forEach((file: File) => {
        const reader = new FileReader();
        reader.onload = (event) => {
          const content = event.target?.result as string;
          setFiles(prev => {
            // Check for duplicates
            if (prev.find(f => f.fileName === file.name)) return prev;
            return [{
              fileName: file.name,
              content: content,
              timestamp: Date.now()
            }, ...prev];
          });
        };
        reader.readAsText(file);
      });
      setIsParsing(false);
      
      // Follow-up indexing simulation
      setIsIndexing(true);
      setTimeout(() => setIsIndexing(false), 2000);
    }, 1500);
  };

  const removeFile = (index: number) => {
    setFiles(prev => prev.filter((_, i) => i !== index));
  };

  const filteredFiles = files.filter(file => 
    file.fileName.toLowerCase().includes(searchQuery.toLowerCase()) || 
    file.content.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const totalChars = files.reduce((acc, f) => acc + f.content.length, 0);

  return (
    <div className="h-full flex flex-col p-8">
      <div className="mb-8 flex justify-between items-start">
        <div>
          <h2 className="text-3xl font-bold tracking-tight text-white mb-2 italic flex items-center gap-3">
            <Icons.Database /> Knowledge Base
          </h2>
          <p className="text-slate-400 italic">Persistent artifact storage and Neural RAG indexing.</p>
        </div>
        <div className="flex flex-col items-end gap-1">
          <span className="text-[10px] font-mono text-slate-500 uppercase">Context Density</span>
          <div className="w-32 h-1.5 bg-slate-800 rounded-full overflow-hidden">
             <div 
              className="h-full bg-blue-500 transition-all duration-1000" 
              style={{ width: `${Math.min((totalChars / 500000) * 100, 100)}%` }}
             ></div>
          </div>
        </div>
      </div>

      <div className="grid lg:grid-cols-3 gap-8 flex-1 overflow-hidden">
        <div className="lg:col-span-1 space-y-6">
          <div 
            onClick={() => fileInputRef.current?.click()}
            className="group cursor-pointer border-2 border-dashed border-slate-700 hover:border-blue-500 hover:bg-blue-500/5 rounded-3xl p-10 flex flex-col items-center justify-center transition-all bg-slate-950/20"
          >
            <div className="p-4 bg-slate-800 rounded-2xl mb-4 group-hover:scale-110 transition-transform shadow-lg group-hover:shadow-blue-500/20">
              <Icons.Upload />
            </div>
            <p className="font-semibold text-center text-slate-200">Inject Data Artifact</p>
            <p className="text-xs text-slate-500 text-center mt-2">Persistence is enabled by default.</p>
            <input 
              type="file" 
              ref={fileInputRef} 
              className="hidden" 
              multiple 
              onChange={handleFileUpload}
            />
          </div>

          <div className="space-y-4">
            <div className="bg-slate-800/30 p-6 rounded-3xl border border-slate-700/50">
              <h4 className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-4">Pipeline Status</h4>
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <span className="text-xs text-slate-500">Ingestion</span>
                  <div className={`w-2 h-2 rounded-full ${isParsing ? 'bg-amber-500 animate-pulse' : 'bg-green-500'}`}></div>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-xs text-slate-500">Neural Indexing</span>
                  <div className={`w-2 h-2 rounded-full ${isIndexing ? 'bg-indigo-500 animate-pulse' : 'bg-green-500'}`}></div>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-xs text-slate-500">Persistence</span>
                  <div className={`w-2 h-2 rounded-full bg-green-500`}></div>
                </div>
              </div>
            </div>

            <div className="bg-blue-900/10 border border-blue-500/10 rounded-2xl p-4">
              <p className="text-[10px] font-mono text-blue-400/80 leading-relaxed uppercase">
                "The mind is not a vessel to be filled, but a fire to be kindled." 
                Your Knowledge Base currently contains {totalChars.toLocaleString()} tokens of semantic mass.
              </p>
            </div>
          </div>
        </div>

        <div className="lg:col-span-2 flex flex-col space-y-4 overflow-hidden">
          <div className="space-y-4">
            <div className="flex justify-between items-center px-2">
              <h3 className="text-lg font-bold text-slate-200">
                Retrieved Artifacts {searchQuery ? `(${filteredFiles.length} of ${files.length})` : `(${files.length})`}
              </h3>
              <button 
                onClick={() => {
                  setIsIndexing(true);
                  setTimeout(() => setIsIndexing(false), 1000);
                }}
                className="text-[10px] font-mono text-blue-400 hover:text-white transition-colors border border-blue-400/30 px-2 py-1 rounded"
              >
                RE-INDEX ALL
              </button>
            </div>

            {/* Artifact Search Bar */}
            <div className="relative group">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <svg className="h-4 w-4 text-slate-500 group-focus-within:text-blue-400 transition-colors" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                </svg>
              </div>
              <input 
                type="text" 
                placeholder="Search artifacts by name or content keywords..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full bg-slate-950/50 border border-slate-800 rounded-xl py-2 pl-10 pr-4 text-sm text-slate-200 placeholder-slate-600 focus:outline-none focus:border-blue-500/50 focus:ring-1 focus:ring-blue-500/20 transition-all"
              />
              {searchQuery && (
                <button 
                  onClick={() => setSearchQuery('')}
                  className="absolute inset-y-0 right-0 pr-3 flex items-center text-slate-500 hover:text-slate-300"
                >
                  <svg className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                  </svg>
                </button>
              )}
            </div>
          </div>
          
          <div className="flex-1 overflow-y-auto pr-2 space-y-3 custom-scrollbar">
            {files.length === 0 ? (
              <div className="h-full flex flex-col items-center justify-center text-slate-600 italic border border-slate-800/50 rounded-2xl border-dashed bg-slate-900/20">
                <Icons.Database />
                <span className="mt-4">Knowledge Base Empty.</span>
              </div>
            ) : filteredFiles.length === 0 ? (
              <div className="h-full flex flex-col items-center justify-center text-slate-600 italic border border-slate-800/50 rounded-2xl border-dashed bg-slate-900/20">
                <svg className="w-8 h-8 mb-2 opacity-20" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9.172 9.172a4 4 0 015.656 0M9 10h.01M15 10h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
                <span>No artifacts matching "{searchQuery}"</span>
              </div>
            ) : (
              filteredFiles.map((file, idx) => {
                // Find index of the file in the original array to maintain consistent key if needed
                const originalIndex = files.findIndex(f => f.fileName === file.fileName);
                return (
                  <div key={file.fileName + file.timestamp} className="bg-slate-900/80 border border-slate-800 p-4 rounded-2xl flex items-start justify-between group hover:border-slate-700 transition-colors shadow-sm">
                    <div className="flex-1 overflow-hidden">
                      <div className="flex items-center gap-2 mb-1">
                        <div className="p-1.5 bg-blue-500/10 rounded text-blue-400">
                          <Icons.Memory />
                        </div>
                        <h4 className="font-bold text-slate-200 truncate">{file.fileName}</h4>
                        <span className="text-[10px] text-slate-600 font-mono ml-auto">{(file.content.length / 1024).toFixed(1)} KB</span>
                      </div>
                      <p className="text-xs text-slate-500 font-mono line-clamp-1 bg-black/20 p-2 rounded mt-2 opacity-60 group-hover:opacity-100 transition-opacity">
                        {file.content}
                      </p>
                    </div>
                    <button 
                      onClick={() => removeFile(originalIndex)}
                      className="ml-4 p-2 text-slate-600 hover:text-red-400 opacity-0 group-hover:opacity-100 transition-opacity"
                    >
                      <svg xmlns="http://www.w3.org/2000/svg" className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                      </svg>
                    </button>
                  </div>
                );
              })
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default BodyLab;