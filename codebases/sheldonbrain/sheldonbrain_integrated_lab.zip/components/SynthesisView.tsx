
import React from 'react';
import { SynthesisOutput } from '../types';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Cell } from 'recharts';

interface Props {
  outputs: SynthesisOutput[];
  isSynthesizing: boolean;
}

const SynthesisView: React.FC<Props> = ({ outputs, isSynthesizing }) => {
  // Mock data for "Synthesis Metrics"
  const chartData = [
    { name: 'Entropy', value: Math.floor(Math.random() * 40) + 60 },
    { name: 'Density', value: Math.floor(Math.random() * 50) + 30 },
    { name: 'Clarity', value: Math.floor(Math.random() * 30) + 70 },
    { name: 'Velocity', value: Math.floor(Math.random() * 60) + 40 },
  ];

  if (isSynthesizing) {
    return (
      <div className="h-full flex flex-col items-center justify-center p-8 space-y-6">
        <div className="relative">
          <div className="w-24 h-24 border-4 border-blue-500/20 border-t-blue-500 rounded-full animate-spin"></div>
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="w-12 h-12 bg-blue-500/20 rounded-full animate-pulse"></div>
          </div>
        </div>
        <div className="text-center space-y-2">
          <h3 className="text-2xl font-bold tracking-widest animate-pulse italic">SYNTHESIZING...</h3>
          <p className="text-slate-500 font-mono text-sm tracking-tighter uppercase">Routing through Core Intelligence neurons</p>
        </div>
      </div>
    );
  }

  if (outputs.length === 0) {
    return (
      <div className="h-full flex items-center justify-center p-8 text-slate-600 italic">
        The Synthesis Engine is cold. Ignite the core to generate insights.
      </div>
    );
  }

  return (
    <div className="h-full flex flex-col p-8 overflow-hidden">
      <div className="mb-8 flex justify-between items-end">
        <div>
          <h2 className="text-3xl font-bold tracking-tight text-white mb-2 italic">Synthesis Complete</h2>
          <p className="text-slate-400">View logical deductions and generated intelligence reports.</p>
        </div>
        <div className="text-xs font-mono text-blue-400 bg-blue-900/20 px-3 py-1 rounded-full border border-blue-500/30 uppercase tracking-widest">
          Active Sessions: {outputs.length}
        </div>
      </div>

      <div className="flex-1 overflow-y-auto space-y-12 pr-4 custom-scrollbar">
        {outputs.map((out, idx) => (
          <div key={idx} className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
            <div className="flex items-center gap-4">
              <span className="bg-blue-600 px-3 py-1 rounded text-xs font-bold uppercase tracking-widest">REPORT_{outputs.length - idx}</span>
              <div className="h-px flex-1 bg-slate-800"></div>
              <span className="text-xs font-mono text-slate-500">{new Date(out.timestamp).toLocaleTimeString()}</span>
            </div>

            <div className="grid lg:grid-cols-3 gap-6">
              <div className="lg:col-span-2 space-y-4">
                <div className="bg-slate-950 border border-slate-800 rounded-3xl p-8 relative overflow-hidden group">
                   <div className="absolute top-0 right-0 p-4 opacity-10 pointer-events-none">
                      <svg width="100" height="100" viewBox="0 0 100 100" className="text-blue-500 fill-current">
                        <path d="M50 0 L100 50 L50 100 L0 50 Z" />
                      </svg>
                   </div>
                  <h4 className="text-blue-400 text-xs font-bold uppercase tracking-widest mb-6 border-b border-slate-800 pb-2">Cognitive Deduction</h4>
                  <div className="prose prose-invert max-w-none prose-sm leading-relaxed text-slate-300">
                    {out.analysis.split('\n').map((line, lIdx) => (
                      <p key={lIdx} className="mb-4">{line}</p>
                    ))}
                  </div>

                  {out.urls && out.urls.length > 0 && (
                    <div className="mt-8 pt-6 border-t border-slate-800">
                      <h5 className="text-xs font-bold text-slate-500 uppercase tracking-widest mb-3">Grounding Context</h5>
                      <div className="flex flex-wrap gap-2">
                        {out.urls.map((u, uIdx) => (
                          u.web ? (
                            <a 
                              key={uIdx} 
                              href={u.web.uri} 
                              target="_blank" 
                              rel="noreferrer"
                              className="text-xs bg-slate-800 hover:bg-slate-700 text-blue-400 border border-slate-700 px-3 py-1.5 rounded-lg transition-colors flex items-center gap-2"
                            >
                              {u.web.title || 'Source'}
                              <svg className="w-3 h-3" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14" />
                              </svg>
                            </a>
                          ) : null
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              </div>

              <div className="lg:col-span-1 space-y-6">
                <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6">
                   <h4 className="text-slate-400 text-xs font-bold uppercase tracking-widest mb-6">Extraction Metrics</h4>
                   <div className="h-48 w-full">
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart data={chartData}>
                        <XAxis dataKey="name" stroke="#475569" fontSize={10} axisLine={false} tickLine={false} />
                        <Tooltip 
                          contentStyle={{ backgroundColor: '#0f172a', border: '1px solid #1e293b', borderRadius: '12px', fontSize: '10px' }}
                          cursor={{ fill: 'rgba(59, 130, 246, 0.1)' }}
                        />
                        <Bar dataKey="value" radius={[4, 4, 0, 0]}>
                          {chartData.map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={index % 2 === 0 ? '#3b82f6' : '#6366f1'} />
                          ))}
                        </Bar>
                      </BarChart>
                    </ResponsiveContainer>
                   </div>
                   <div className="mt-4 grid grid-cols-2 gap-2">
                      {chartData.map((item, i) => (
                        <div key={i} className="bg-slate-950 p-2 rounded-lg border border-slate-800">
                          <p className="text-[10px] text-slate-500 uppercase">{item.name}</p>
                          <p className="text-sm font-bold text-slate-200">{item.value}%</p>
                        </div>
                      ))}
                   </div>
                </div>

                <div className="bg-slate-900/50 border border-slate-800/50 rounded-3xl p-6">
                  <h4 className="text-slate-500 text-xs font-bold uppercase tracking-widest mb-4 italic">Bazinga Status</h4>
                  <p className="text-xs text-slate-400 leading-relaxed">
                    Synthesis achieved with high logical fidelity. Core Intelligence alignment confirmed.
                  </p>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default SynthesisView;
