
export enum LabView {
  MIND = 'MIND',
  BODY = 'BODY',
  SYNTHESIS = 'SYNTHESIS'
}

export interface LabConfig {
  systemInstruction: string;
  temperature: number;
  topP: number;
  topK: number;
  model: string;
}

export interface ParseResult {
  fileName: string;
  content: string;
  timestamp: number;
}

export interface SynthesisOutput {
  raw: string;
  analysis: string;
  timestamp: number;
  urls?: { web: { uri: string; title: string } }[];
}
