
import { GoogleGenAI, GenerateContentResponse } from "@google/genai";
import { LabConfig } from "../types";

export const synthesizeData = async (
  config: LabConfig,
  input: string
): Promise<{ text: string; urls?: any[] }> => {
  // Use API key directly from environment variable as per guidelines
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  
  try {
    const response: GenerateContentResponse = await ai.models.generateContent({
      model: config.model,
      contents: input,
      config: {
        systemInstruction: config.systemInstruction,
        temperature: config.temperature,
        topP: config.topP,
        topK: config.topK,
        // Optional: Google Search for up-to-date grounding
        tools: [{ googleSearch: {} }]
      },
    });

    return {
      text: response.text || "No response received.",
      urls: response.candidates?.[0]?.groundingMetadata?.groundingChunks || []
    };
  } catch (error) {
    console.error("Gemini API Error:", error);
    throw error;
  }
};
