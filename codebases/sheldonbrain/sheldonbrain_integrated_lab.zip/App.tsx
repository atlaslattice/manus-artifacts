
import React, { useState, useEffect, useCallback } from 'react';
import { LabView, LabConfig, ParseResult, SynthesisOutput } from './types';
import { DEFAULT_CONFIG, Icons } from './constants';
import MindLab from './components/MindLab';
import BodyLab from './components/BodyLab';
import SynthesisView from './components/SynthesisView';
import { synthesizeData } from './services/geminiService';

const App: React.FC = () => {
  const [currentView, setCurrentView] = useState<LabView>(LabView.MIND);
  const [config, setConfig] = useState<LabConfig>(() => {
    const saved = localStorage.getItem('sheldonbrain_config');
    return saved ? JSON.parse(saved) : DEFAULT_CONFIG;
  });
  const [parsedFiles, setParsedFiles] = useState<ParseResult[]>(() => {
    const saved = localStorage.getItem('sheldonbrain_files');
    return saved ? JSON.parse(saved) : [];
  });
  const [outputs, setOutputs] = useState<SynthesisOutput[]>(() => {
    const saved = localStorage.getItem('sheldonbrain_outputs');
    return saved ? JSON.parse(saved) : [];
  });
  const [isSynthesizing, setIsSynthesizing] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Persistence side effects
  useEffect(() => {
    localStorage.setItem('sheldonbrain_config', JSON.stringify(config));
  }, [config]);

  useEffect(() => {
    localStorage.setItem('sheldonbrain_files', JSON.stringify(parsedFiles));
  }, [parsedFiles]);

  useEffect(() => {
    localStorage.setItem('sheldonbrain_outputs', JSON.stringify(outputs));
  }, [outputs]);

  const handleSynthesize = async () => {
    if (parsedFiles.length === 0) {
      setError("RAG FAILURE: No artifacts in Knowledge Base. Feed the Body Lab first.");
      setCurrentView(LabView.BODY);
      return;
    }

    setIsSynthesizing(true);
    setError(null);
    setCurrentView(LabView.SYNTHESIS);

    // Structural RAG Prompt
    const retrievalHeader = `[RETRIEVED KNOWLEDGE BASE - ${parsedFiles.length} ARTIFACTS FOUND]\n\n`;
    const fullContext = retrievalHeader + parsedFiles.map(f => `--- ARTIFACT: ${f.fileName} ---\n${f.content}`).join('\n\n');

    try {
      const result = await synthesizeData(config, fullContext);
      const newOutput: SynthesisOutput = {
        raw: fullContext,
        analysis: result.text,
        timestamp: Date.now(),
        urls: result.urls
      };
      setOutputs(prev => [newOutput, ...prev]);
    } catch (err: any) {
      setError(err.message || "Synthesis failed.");
    } finally {
      setIsSynthesizing(false);
    }
  };

  const clearLab = () => {
    if (window.confirm("Nuclear clear initiated. Wipe all memory?")) {
      setParsedFiles([]);
      setOutputs([]);
      localStorage.removeItem('sheldonbrain_files');
      localStorage.removeItem('sheldonbrain_outputs');
      setError(null);
    }
  };

  return (
    <div className="flex h-screen bg-slate-950 text-slate-100 overflow-hidden">
      {/* Sidebar */}
      <nav className="w-20 lg:w-64 bg-slate-900 border-r border-slate-800 flex flex-col p-4">
        <div className="mb-10 flex items-center gap-3 px-2">
          <div className="p-2 bg-blue-600 rounded-lg shadow-[0_0_15px_rgba(37,99,235,0.4)]">
            <Icons.Lightning />
          </div>
          <h1 className="hidden lg:block font-bold text-xl tracking-tighter">SHELDONBRAIN</h1>
        </div>

        <div className="flex-1 space-y-2">
          <button
            onClick={() => setCurrentView(LabView.MIND)}
            className={`w-full flex items-center gap-3 p-3 rounded-xl transition-all ${currentView === LabView.MIND ? 'bg-blue-600 text-white shadow-lg shadow-blue-900/20' : 'text-slate-400 hover:bg-slate-800'}`}
          >
            <Icons.Brain />
            <span className="hidden lg:block font-medium">The Mind (Config)</span>
          </button>
          
          <button
            onClick={() => setCurrentView(LabView.BODY)}
            className={`w-full flex items-center gap-3 p-3 rounded-xl transition-all ${currentView === LabView.BODY ? 'bg-blue-600 text-white shadow-lg shadow-blue-900/20' : 'text-slate-400 hover:bg-slate-800'}`}
          >
            <Icons.Database />
            <span className="hidden lg:block font-medium">Knowledge Base</span>
          </button>

          <button
            onClick={() => setCurrentView(LabView.SYNTHESIS)}
            className={`w-full flex items-center gap-3 p-3 rounded-xl transition-all ${currentView === LabView.SYNTHESIS ? 'bg-blue-600 text-white shadow-lg shadow-blue-900/20' : 'text-slate-400 hover:bg-slate-800'}`}
          >
            <Icons.Lightning />
            <span className="hidden lg:block font-medium">Synthesis Engine</span>
          </button>
        </div>

        <div className="pt-6 border-t border-slate-800">
          <div className="mb-4 flex items-center gap-2 px-2">
            <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse"></div>
            <span className="text-[10px] font-mono text-slate-500 uppercase tracking-widest">Memory Active</span>
          </div>
          
           <button
            onClick={handleSynthesize}
            disabled={isSynthesizing}
            className={`w-full py-4 px-2 rounded-xl bg-gradient-to-br from-indigo-500 to-blue-600 font-bold text-sm tracking-widest hover:scale-[1.02] active:scale-95 transition-all shadow-xl shadow-blue-600/10 disabled:opacity-50 flex items-center justify-center gap-2`}
          >
            {isSynthesizing ? 'SYNTHESIZING...' : 'IGNITE CORE'}
          </button>
          <button 
            onClick={clearLab}
            className="w-full mt-4 text-xs text-slate-500 hover:text-red-400 transition-colors uppercase tracking-tighter"
          >
            Wipe Persistent Memory
          </button>
        </div>
      </nav>

      {/* Main Content Area */}
      <main className="flex-1 overflow-y-auto bg-[url('https://www.transparenttextures.com/patterns/carbon-fibre.png')]">
        <div className="max-w-6xl mx-auto p-6 md:p-10 h-full flex flex-col">
          {error && (
            <div className="mb-6 p-4 bg-red-900/20 border border-red-500/50 rounded-xl flex items-center gap-3 text-red-200 animate-in fade-in duration-300">
              <span className="font-bold">SYSTEM ERROR:</span> {error}
            </div>
          )}

          <div className="flex-1 bg-slate-900/40 backdrop-blur-xl border border-slate-800/50 rounded-3xl overflow-hidden shadow-2xl">
            {currentView === LabView.MIND && (
              <MindLab config={config} setConfig={setConfig} />
            )}
            {currentView === LabView.BODY && (
              <BodyLab files={parsedFiles} setFiles={setParsedFiles} />
            )}
            {currentView === LabView.SYNTHESIS && (
              <SynthesisView 
                outputs={outputs} 
                isSynthesizing={isSynthesizing} 
              />
            )}
          </div>
        </div>
      </main>
    </div>
  );
};

export default App;
