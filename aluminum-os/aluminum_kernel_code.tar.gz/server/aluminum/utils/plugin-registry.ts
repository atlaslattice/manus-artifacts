/**
 * Aluminum Plugin Registry
 * 
 * Manages registration and discovery of plugins that attach to the Aluminum kernel.
 * Plugins register their capabilities, and the Intent Routing API queries this registry
 * to find the best plugin to handle a given intent.
 */

import type {
  PluginDescriptor,
  PluginIntentScore,
  PluginIntentPlan,
  IntentRoutingInput,
} from "../types/kernel";

export interface Plugin {
  descriptor: PluginDescriptor;
  canHandle: (intent: IntentRoutingInput) => Promise<PluginIntentScore>;
  handle: (intent: IntentRoutingInput) => Promise<PluginIntentPlan>;
}

class PluginRegistry {
  private plugins: Map<string, Plugin> = new Map();

  /**
   * Register a plugin with the kernel
   */
  register(plugin: Plugin): void {
    const { plugin_id } = plugin.descriptor;
    
    if (this.plugins.has(plugin_id)) {
      throw new Error(`Plugin ${plugin_id} is already registered`);
    }

    this.plugins.set(plugin_id, plugin);
    console.log(`[PluginRegistry] Registered plugin: ${plugin_id}`);
  }

  /**
   * Unregister a plugin from the kernel
   */
  unregister(plugin_id: string): boolean {
    const removed = this.plugins.delete(plugin_id);
    if (removed) {
      console.log(`[PluginRegistry] Unregistered plugin: ${plugin_id}`);
    }
    return removed;
  }

  /**
   * Get a plugin by ID
   */
  getPlugin(plugin_id: string): Plugin | undefined {
    return this.plugins.get(plugin_id);
  }

  /**
   * Get all registered plugins
   */
  getAllPlugins(): Plugin[] {
    return Array.from(this.plugins.values());
  }

  /**
   * Get all plugin descriptors
   */
  getAllDescriptors(): PluginDescriptor[] {
    return Array.from(this.plugins.values()).map((p) => p.descriptor);
  }

  /**
   * Find plugins that can handle a given intent
   * Returns plugins sorted by score (highest first)
   */
  async findCandidates(
    intent: IntentRoutingInput
  ): Promise<Array<{ plugin: Plugin; score: PluginIntentScore }>> {
    const candidates: Array<{ plugin: Plugin; score: PluginIntentScore }> = [];

    // Query all plugins to see if they can handle this intent
    for (const plugin of Array.from(this.plugins.values())) {
      try {
        const score = await plugin.canHandle(intent);
        if (score.can_handle && score.score > 0) {
          candidates.push({ plugin, score });
        }
      } catch (error) {
        console.error(
          `[PluginRegistry] Error checking plugin ${plugin.descriptor.plugin_id}:`,
          error
        );
      }
    }

    // Sort by score (highest first)
    candidates.sort((a, b) => b.score.score - a.score.score);

    return candidates;
  }

  /**
   * Find the best plugin to handle a given intent
   */
  async findBestPlugin(
    intent: IntentRoutingInput
  ): Promise<{ plugin: Plugin; score: PluginIntentScore } | null> {
    const candidates = await this.findCandidates(intent);
    return candidates.length > 0 ? candidates[0] : null;
  }

  /**
   * Search plugins by capability
   */
  findByCapability(capability: string): Plugin[] {
    return Array.from(this.plugins.values()).filter((plugin) =>
      plugin.descriptor.capabilities.includes(capability)
    );
  }

  /**
   * Search plugins by account type
   */
  findByAccountType(accountType: string): Plugin[] {
    return Array.from(this.plugins.values()).filter(
      (plugin) =>
        plugin.descriptor.supported_accounts?.includes(accountType)
    );
  }

  /**
   * Get plugin statistics
   */
  getStats(): {
    total_plugins: number;
    plugins_by_capability: Record<string, number>;
    plugins_by_account_type: Record<string, number>;
  } {
    const plugins_by_capability: Record<string, number> = {};
    const plugins_by_account_type: Record<string, number> = {};

    for (const plugin of Array.from(this.plugins.values())) {
      // Count capabilities
      for (const capability of plugin.descriptor.capabilities) {
        plugins_by_capability[capability] =
          (plugins_by_capability[capability] || 0) + 1;
      }

      // Count account types
      if (plugin.descriptor.supported_accounts) {
        for (const accountType of plugin.descriptor.supported_accounts) {
          plugins_by_account_type[accountType] =
            (plugins_by_account_type[accountType] || 0) + 1;
        }
      }
    }

    return {
      total_plugins: this.plugins.size,
      plugins_by_capability,
      plugins_by_account_type,
    };
  }

  /**
   * Clear all registered plugins (useful for testing)
   */
  clear(): void {
    this.plugins.clear();
    console.log("[PluginRegistry] Cleared all plugins");
  }
}

// Singleton instance
export const pluginRegistry = new PluginRegistry();
