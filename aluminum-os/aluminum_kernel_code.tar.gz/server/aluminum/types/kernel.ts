/**
 * Aluminum v2.1 Kernel Types
 * 
 * TypeScript type definitions for the five canonical kernel APIs:
 * 1. Intent Routing API
 * 2. Policy Kernel API
 * 3. Provenance API
 * 4. State/Version Control API
 * 5. Executor Adapter API
 */

// ============================================================================
// INTENT ROUTING API TYPES
// ============================================================================

export interface IntentContext {
  active_app?: string;
  selection?: string | object;
  user_state?: {
    primary_email?: string;
    recent_contacts?: string[];
    preferences?: Record<string, unknown>;
    history?: unknown[];
  };
  device_info?: {
    type?: string;
    capabilities?: string[];
    location?: string;
  };
}

export interface IntentConstraints {
  time_limit?: number;
  risk_level?: "low" | "medium" | "high";
  device_restrictions?: string[];
  privacy_requirements?: string;
}

export interface ActionSchema {
  target: string;
  selector?: string;
  operation: string;
  parameters: Record<string, unknown>;
  preconditions?: Array<{
    type: string;
    selector?: string;
    [key: string]: unknown;
  }>;
  postconditions?: Array<{
    type: string;
    selector?: string;
    [key: string]: unknown;
  }>;
  idempotency_key?: string;
}

export interface PlanStep {
  step_id: string;
  action_schema: ActionSchema;
  dependencies?: string[];
  estimated_duration?: number;
}

export interface IntentRoutingInput {
  intent_text: string;
  context_snapshot: IntentContext;
  constraints: IntentConstraints;
}

export interface IntentRoutingOutput {
  selected_agent: string;
  plan: PlanStep[];
  confidence: number;
  alternatives?: string[];
}

// ============================================================================
// POLICY KERNEL API TYPES
// ============================================================================

export type PolicyDecision = "allow" | "requires_approval" | "block";

export interface PolicyContext {
  user_id: string;
  device_id: string;
  app_context?: Record<string, unknown>;
  risk_profile?: string;
}

export interface LoggingDirectives {
  log_level: "minimal" | "standard" | "detailed" | "verbose";
  destinations: string[];
  retention_policy: string;
}

export interface RequiredApproval {
  approver_id: string;
  approval_type: string;
  timeout: number;
}

export interface PolicyKernelInput {
  plan: PlanStep[];
  context: PolicyContext;
  policy_version: string;
}

export interface PolicyKernelOutput {
  decision: PolicyDecision;
  rationale: string;
  logging_directives: LoggingDirectives;
  required_approvals?: RequiredApproval[];
}

// ============================================================================
// PROVENANCE API TYPES
// ============================================================================

export type ArtifactType =
  | "message"
  | "file"
  | "event"
  | "state_change"
  | "approval"
  | "policy_decision";

export interface ProducedBy {
  agent_id: string;
  model_version?: string;
  plugin_version?: string;
}

export interface PolicyRegime {
  constitution_version: string;
  rules_triggered?: string[];
  policy_decision_id?: string;
}

export interface Timestamps {
  created_at: string;
  modified_at?: string;
  executed_at?: string;
}

export interface Approval {
  approver_id: string;
  approval_type: string;
  signature: string;
  timestamp: string;
}

export interface ProvenanceInput {
  artifact_type: ArtifactType;
  content_hash: string;
  parents?: string[];
  produced_by: ProducedBy;
  policy_regime: PolicyRegime;
  executor: string;
  timestamps: Timestamps;
  approvals?: Approval[];
}

export interface ProvenanceOutput {
  artifact_id: string;
  provenance_record_location: string;
}

// ============================================================================
// STATE / VERSION CONTROL API TYPES
// ============================================================================

export type VersionControlOperation = "branch" | "merge" | "diff" | "revert";

export type MergeStrategy = "ours" | "theirs" | "manual";

export interface BranchInput {
  target_id: string;
  label: string;
}

export interface BranchOutput {
  new_branch_id: string;
  snapshot_id: string;
  parent_id: string;
}

export interface MergeInput {
  source_branch: string;
  target_branch: string;
  strategy: MergeStrategy;
}

export interface ConflictReport {
  conflicts: Array<{
    path: string;
    source_value: unknown;
    target_value: unknown;
  }>;
}

export interface MergeOutput {
  merged_state: string;
  conflict_report?: ConflictReport;
}

export interface DiffInput {
  a: string;
  b: string;
}

export interface StructuredDiff {
  added_elements: unknown[];
  removed_elements: unknown[];
  modified_elements: Array<{
    id: string;
    old_value: unknown;
    new_value: unknown;
  }>;
  metadata_changes?: Record<string, unknown>;
}

export interface DiffOutput {
  diff: StructuredDiff;
}

export interface RevertInput {
  target_id: string;
  snapshot_id: string;
}

export interface RevertOutput {
  restored_state: string;
  reverted_changes: string[];
}

// ============================================================================
// EXECUTOR ADAPTER API TYPES
// ============================================================================

export interface ExecutorInput {
  action_schema: ActionSchema;
}

export interface ExecutionResult {
  success: boolean;
  data?: Record<string, unknown>;
  error?: {
    code: string;
    message: string;
    details?: unknown;
  };
}

export interface ExecutionReceipts {
  log_entries: string[];
  artifact_ids: string[];
  screenshots?: string[];
}

export interface ExecutorOutput {
  result: ExecutionResult;
  receipts: ExecutionReceipts;
  undo_handle?: string;
}

// ============================================================================
// PLUGIN REGISTRY TYPES
// ============================================================================

export interface PluginCapability {
  domain: string;
  action: string;
  description?: string;
}

export interface PluginDescriptor {
  plugin_id: string;
  plugin_name: string;
  plugin_version: string;
  capabilities: string[];
  supported_accounts?: string[];
  required_permissions?: string[];
  executor_type: string;
}

export interface PluginIntentScore {
  can_handle: boolean;
  score: number;
  rationale?: string;
}

export interface PluginIntentPlan {
  plan: PlanStep[];
  estimated_duration: number;
  required_permissions: string[];
}

// ============================================================================
// UNIFIED MESSAGE SCHEMA (for Messaging Plugin)
// ============================================================================

export interface MessageParticipant {
  name: string;
  address: string;
  account_type?: string;
}

export interface MessageBody {
  html?: string;
  text: string;
}

export interface MessageAttachment {
  file_id: string;
  filename: string;
  mime_type: string;
  size_bytes: number;
}

export interface UnifiedMessage {
  message_id: string;
  thread_id: string;
  from: MessageParticipant;
  to: MessageParticipant[];
  cc?: MessageParticipant[];
  bcc?: MessageParticipant[];
  subject: string;
  body: MessageBody;
  attachments?: MessageAttachment[];
  timestamp_sent: string;
  timestamp_received: string;
  labels?: string[];
  source_system: string;
  raw_metadata?: Record<string, unknown>;
}

// ============================================================================
// CONSTITUTIONAL RULES TYPES
// ============================================================================

export interface ConstitutionalRule {
  rule_id: string;
  rule_text: string;
  rule_type: "allow" | "block" | "require_approval";
  priority: number;
  conditions?: Array<{
    field: string;
    operator: string;
    value: unknown;
  }>;
  created_at: string;
  updated_at?: string;
}

// ============================================================================
// UNDO / REVERSIBILITY TYPES
// ============================================================================

export interface UndoHandle {
  handle_id: string;
  artifact_id: string;
  undo_type: "immediate" | "deferred" | "snapshot" | "provenance";
  undo_action?: ActionSchema;
  snapshot_data?: unknown;
  created_at: string;
  expires_at?: string;
}

// ============================================================================
// KERNEL ERROR TYPES
// ============================================================================

export class AluminumKernelError extends Error {
  constructor(
    message: string,
    public code: string,
    public details?: unknown
  ) {
    super(message);
    this.name = "AluminumKernelError";
  }
}

export class IntentRoutingError extends AluminumKernelError {
  constructor(message: string, details?: unknown) {
    super(message, "INTENT_ROUTING_ERROR", details);
    this.name = "IntentRoutingError";
  }
}

export class PolicyKernelError extends AluminumKernelError {
  constructor(message: string, details?: unknown) {
    super(message, "POLICY_KERNEL_ERROR", details);
    this.name = "PolicyKernelError";
  }
}

export class ProvenanceError extends AluminumKernelError {
  constructor(message: string, details?: unknown) {
    super(message, "PROVENANCE_ERROR", details);
    this.name = "ProvenanceError";
  }
}

export class VersionControlError extends AluminumKernelError {
  constructor(message: string, details?: unknown) {
    super(message, "VERSION_CONTROL_ERROR", details);
    this.name = "VersionControlError";
  }
}

export class ExecutorAdapterError extends AluminumKernelError {
  constructor(message: string, details?: unknown) {
    super(message, "EXECUTOR_ADAPTER_ERROR", details);
    this.name = "ExecutorAdapterError";
  }
}
