/**
 * Aluminum State/Version Control API
 * 
 * Treats conversations, artifacts, and system state as versioned entities
 * that can be branched, merged, diffed, and reverted.
 * 
 * This enables safe experimentation and reversibility at the conversation level.
 */

import type {
  BranchInput,
  BranchOutput,
  MergeInput,
  MergeOutput,
  DiffInput,
  DiffOutput,
  RevertInput,
  RevertOutput,
  StructuredDiff,
} from "../types/kernel";
import { VersionControlError } from "../types/kernel";

/**
 * Snapshot storage
 * In a real implementation, this would be stored in a database
 */
interface Snapshot {
  snapshot_id: string;
  target_id: string;
  label?: string;
  state: unknown;
  parent_snapshot_id?: string;
  created_at: string;
}

const snapshots: Map<string, Snapshot> = new Map();
const branches: Map<string, string> = new Map(); // branch_id -> snapshot_id

/**
 * Create a new branch from an existing state
 */
export async function branch(input: BranchInput): Promise<BranchOutput> {
  try {
    console.log(`[VersionControl] Creating branch from ${input.target_id}`);

    // Get current state (or create empty state if target doesn't exist)
    let currentState = await getState(input.target_id);
    if (!currentState) {
      // Create initial empty state for new targets
      currentState = { _initial: true };
    }

    // Create snapshot of current state
    const snapshot_id = generateSnapshotId();
    const snapshot: Snapshot = {
      snapshot_id,
      target_id: input.target_id,
      label: input.label,
      state: currentState,
      created_at: new Date().toISOString(),
    };

    snapshots.set(snapshot_id, snapshot);

    // Create new branch
    const new_branch_id = `${input.target_id}_branch_${Date.now()}`;
    branches.set(new_branch_id, snapshot_id);

    console.log(`[VersionControl] Created branch: ${new_branch_id}`);

    return {
      new_branch_id,
      snapshot_id,
      parent_id: input.target_id,
    };
  } catch (error) {
    if (error instanceof VersionControlError) {
      throw error;
    }
    throw new VersionControlError(
      `Failed to create branch: ${error instanceof Error ? error.message : String(error)}`,
      { original_error: error }
    );
  }
}

/**
 * Merge two branches
 */
export async function merge(input: MergeInput): Promise<MergeOutput> {
  try {
    console.log(`[VersionControl] Merging ${input.source_branch} into ${input.target_branch}`);

    // Get states of both branches
    const sourceState = await getState(input.source_branch);
    const targetState = await getState(input.target_branch);

    if (!sourceState || !targetState) {
      throw new VersionControlError("Source or target branch not found");
    }

    // Compute diff
    const diff = computeDiff(targetState, sourceState);

    // Check for conflicts
    const conflicts = detectConflicts(diff);

    if (conflicts.length > 0 && input.strategy === "manual") {
      // Return conflicts for manual resolution
      return {
        merged_state: input.target_branch,
        conflict_report: {
          conflicts: conflicts.map((c) => ({
            path: c.path,
            source_value: c.source_value,
            target_value: c.target_value,
          })),
        },
      };
    }

    // Apply merge strategy
    const merged = applyMergeStrategy(targetState, sourceState, diff, input.strategy);

    // Create snapshot of merged state
    const snapshot_id = generateSnapshotId();
    const snapshot: Snapshot = {
      snapshot_id,
      target_id: input.target_branch,
      label: `Merged from ${input.source_branch}`,
      state: merged,
      created_at: new Date().toISOString(),
    };

    snapshots.set(snapshot_id, snapshot);

    // Update target branch to point to merged snapshot
    branches.set(input.target_branch, snapshot_id);

    console.log(`[VersionControl] Merge complete: ${snapshot_id}`);

    return {
      merged_state: input.target_branch,
      conflict_report: conflicts.length > 0 ? {
        conflicts: conflicts.map((c) => ({
          path: c.path,
          source_value: c.source_value,
          target_value: c.target_value,
        })),
      } : undefined,
    };
  } catch (error) {
    if (error instanceof VersionControlError) {
      throw error;
    }
    throw new VersionControlError(
      `Failed to merge: ${error instanceof Error ? error.message : String(error)}`,
      { original_error: error }
    );
  }
}

/**
 * Compute structured diff between two states
 */
export async function diff(input: DiffInput): Promise<DiffOutput> {
  try {
    console.log(`[VersionControl] Computing diff between ${input.a} and ${input.b}`);

    const stateA = await getState(input.a);
    const stateB = await getState(input.b);

    if (!stateA || !stateB) {
      throw new VersionControlError("One or both states not found");
    }

    const structuredDiff = computeDiff(stateA, stateB);

    return {
      diff: structuredDiff,
    };
  } catch (error) {
    if (error instanceof VersionControlError) {
      throw error;
    }
    throw new VersionControlError(
      `Failed to compute diff: ${error instanceof Error ? error.message : String(error)}`,
      { original_error: error }
    );
  }
}

/**
 * Revert to a previous snapshot
 */
export async function revert(input: RevertInput): Promise<RevertOutput> {
  try {
    console.log(`[VersionControl] Reverting ${input.target_id} to ${input.snapshot_id}`);

    const snapshot = snapshots.get(input.snapshot_id);
    if (!snapshot) {
      throw new VersionControlError(`Snapshot ${input.snapshot_id} not found`);
    }

    // Restore state
    await setState(input.target_id, snapshot.state);

    // Track what was reverted
    const reverted_changes = await computeRevertedChanges(input.target_id, snapshot);

    console.log(`[VersionControl] Reverted ${reverted_changes.length} changes`);

    return {
      restored_state: input.target_id,
      reverted_changes,
    };
  } catch (error) {
    if (error instanceof VersionControlError) {
      throw error;
    }
    throw new VersionControlError(
      `Failed to revert: ${error instanceof Error ? error.message : String(error)}`,
      { original_error: error }
    );
  }
}

/**
 * Get all snapshots for a target
 */
export async function getSnapshots(target_id: string): Promise<Snapshot[]> {
  const results: Snapshot[] = [];

  for (const snapshot of Array.from(snapshots.values())) {
    if (snapshot.target_id === target_id) {
      results.push(snapshot);
    }
  }

  // Sort by creation time (newest first)
  results.sort((a, b) => 
    new Date(b.created_at).getTime() - new Date(a.created_at).getTime()
  );

  return results;
}

/**
 * Get all branches
 */
export function getBranches(): Array<{ branch_id: string; snapshot_id: string }> {
  return Array.from(branches.entries()).map(([branch_id, snapshot_id]) => ({
    branch_id,
    snapshot_id,
  }));
}

/**
 * Delete a branch
 */
export function deleteBranch(branch_id: string): boolean {
  return branches.delete(branch_id);
}

// ============================================================================
// HELPER FUNCTIONS
// ============================================================================

/**
 * Get state of a target (stub implementation)
 * In a real implementation, this would fetch from database or memory
 */
async function getState(target_id: string): Promise<unknown> {
  // Check if it's a branch
  const snapshot_id = branches.get(target_id);
  if (snapshot_id) {
    const snapshot = snapshots.get(snapshot_id);
    return snapshot?.state;
  }

  // Check if it's a snapshot
  const snapshot = snapshots.get(target_id);
  if (snapshot) {
    return snapshot.state;
  }

  // Return null if not found
  return null;
}

/**
 * Set state of a target (stub implementation)
 */
async function setState(target_id: string, state: unknown): Promise<void> {
  // Create a new snapshot
  const snapshot_id = generateSnapshotId();
  const snapshot: Snapshot = {
    snapshot_id,
    target_id,
    state,
    created_at: new Date().toISOString(),
  };

  snapshots.set(snapshot_id, snapshot);

  // Update branch pointer if it's a branch
  if (branches.has(target_id)) {
    branches.set(target_id, snapshot_id);
  }
}

/**
 * Compute structured diff between two states
 */
function computeDiff(a: unknown, b: unknown): StructuredDiff {
  // Simple array-based diff for now
  // In a real implementation, this would be more sophisticated

  const added_elements: unknown[] = [];
  const removed_elements: unknown[] = [];
  const modified_elements: Array<{
    id: string;
    old_value: unknown;
    new_value: unknown;
  }> = [];

  // If both are arrays, compute array diff
  if (Array.isArray(a) && Array.isArray(b)) {
    // Find added elements (in b but not in a)
    for (const item of b) {
      if (!a.includes(item)) {
        added_elements.push(item);
      }
    }

    // Find removed elements (in a but not in b)
    for (const item of a) {
      if (!b.includes(item)) {
        removed_elements.push(item);
      }
    }
  }

  // If both are objects, compute object diff
  if (typeof a === "object" && typeof b === "object" && a !== null && b !== null) {
    const aObj = a as Record<string, unknown>;
    const bObj = b as Record<string, unknown>;

    // Find added/modified properties
    for (const key in bObj) {
      if (!(key in aObj)) {
        added_elements.push({ [key]: bObj[key] });
      } else if (aObj[key] !== bObj[key]) {
        modified_elements.push({
          id: key,
          old_value: aObj[key],
          new_value: bObj[key],
        });
      }
    }

    // Find removed properties
    for (const key in aObj) {
      if (!(key in bObj)) {
        removed_elements.push({ [key]: aObj[key] });
      }
    }
  }

  return {
    added_elements,
    removed_elements,
    modified_elements,
  };
}

/**
 * Detect conflicts in a diff
 */
function detectConflicts(diff: StructuredDiff): Array<{
  path: string;
  source_value: unknown;
  target_value: unknown;
}> {
  // For now, treat all modified elements as potential conflicts
  return diff.modified_elements.map((m) => ({
    path: m.id,
    source_value: m.new_value,
    target_value: m.old_value,
  }));
}

/**
 * Apply merge strategy
 */
function applyMergeStrategy(
  target: unknown,
  source: unknown,
  diff: StructuredDiff,
  strategy: "ours" | "theirs" | "manual"
): unknown {
  if (strategy === "ours") {
    // Keep target state
    return target;
  } else if (strategy === "theirs") {
    // Use source state
    return source;
  } else {
    // Manual merge (return target for now, conflicts should be resolved externally)
    return target;
  }
}

/**
 * Compute what changes were reverted
 */
async function computeRevertedChanges(
  target_id: string,
  snapshot: Snapshot
): Promise<string[]> {
  // Get current state
  const currentState = await getState(target_id);
  
  // Compute diff
  const diff = computeDiff(snapshot.state, currentState);

  // Return IDs of modified elements
  return diff.modified_elements.map((m) => m.id);
}

/**
 * Generate a unique snapshot ID
 */
function generateSnapshotId(): string {
  return `snapshot_${Date.now()}_${Math.random().toString(36).substring(7)}`;
}

/**
 * Clear all snapshots and branches (useful for testing)
 */
export function clearVersionControl(): void {
  snapshots.clear();
  branches.clear();
  console.log("[VersionControl] Cleared all snapshots and branches");
}
