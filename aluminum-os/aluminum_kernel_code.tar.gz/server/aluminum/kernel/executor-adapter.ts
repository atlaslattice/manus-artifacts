/**
 * Aluminum Executor Adapter API
 * 
 * Unified interface for executing actions across different platforms and executors
 * (DOM manipulation, API calls, native OS operations, etc.).
 * 
 * This abstracts away platform-specific details and provides a consistent interface
 * for all plugins.
 */

import type {
  ExecutorInput,
  ExecutorOutput,
  ActionSchema,
  ExecutionResult,
} from "../types/kernel";
import { ExecutorAdapterError } from "../types/kernel";
import { logProvenance } from "./provenance";

/**
 * Executor interface that all platform-specific executors must implement
 */
export interface Executor {
  executor_id: string;
  executor_type: string;
  canExecute: (action: ActionSchema) => boolean;
  execute: (action: ActionSchema) => Promise<ExecutionResult>;
  undo?: (undo_handle: string) => Promise<ExecutionResult>;
}

/**
 * Registry of available executors
 */
const executors: Map<string, Executor> = new Map();

/**
 * Register an executor
 */
export function registerExecutor(executor: Executor): void {
  executors.set(executor.executor_id, executor);
  console.log(`[ExecutorAdapter] Registered executor: ${executor.executor_id}`);
}

/**
 * Unregister an executor
 */
export function unregisterExecutor(executor_id: string): boolean {
  const removed = executors.delete(executor_id);
  if (removed) {
    console.log(`[ExecutorAdapter] Unregistered executor: ${executor_id}`);
  }
  return removed;
}

/**
 * Execute an action using the appropriate executor
 */
export async function executeAction(
  input: ExecutorInput
): Promise<ExecutorOutput> {
  try {
    console.log(`[ExecutorAdapter] Executing action: ${input.action_schema.operation}`);

    // Find an executor that can handle this action
    const executor = findExecutor(input.action_schema);
    if (!executor) {
      throw new ExecutorAdapterError(
        `No executor available for action: ${input.action_schema.operation}`,
        { action: input.action_schema }
      );
    }

    // Check preconditions
    const preconditionsmet = await checkPreconditions(input.action_schema);
    if (!preconditionsmet.success) {
      throw new ExecutorAdapterError(
        `Preconditions not met: ${preconditionsmet.error?.message}`,
        { action: input.action_schema, preconditions: input.action_schema.preconditions }
      );
    }

    // Execute the action
    const result = await executor.execute(input.action_schema);

    // Check postconditions
    if (result.success) {
      const postconditionsMet = await checkPostconditions(input.action_schema, result);
      if (!postconditionsMet.success) {
        console.warn(
          `[ExecutorAdapter] Postconditions not met for action: ${input.action_schema.operation}`
        );
      }
    }

    // Generate execution receipts
    const receipts = await generateReceipts(input.action_schema, result, executor);

    // Generate undo handle if action is reversible
    const undo_handle = result.success && executor.undo
      ? await generateUndoHandle(input.action_schema, executor)
      : undefined;

    console.log(
      `[ExecutorAdapter] Action executed: ${result.success ? "success" : "failure"}`
    );

    return {
      result,
      receipts,
      undo_handle,
    };
  } catch (error) {
    if (error instanceof ExecutorAdapterError) {
      throw error;
    }
    throw new ExecutorAdapterError(
      `Failed to execute action: ${error instanceof Error ? error.message : String(error)}`,
      { original_error: error }
    );
  }
}

/**
 * Undo a previously executed action
 */
export async function undoAction(undo_handle: string): Promise<ExecutionResult> {
  try {
    console.log(`[ExecutorAdapter] Undoing action: ${undo_handle}`);

    // Parse undo handle to get executor and action info
    const { executor_id, action_info } = parseUndoHandle(undo_handle);

    // Get executor
    const executor = executors.get(executor_id);
    if (!executor || !executor.undo) {
      throw new ExecutorAdapterError(
        `Executor ${executor_id} does not support undo`,
        { undo_handle }
      );
    }

    // Execute undo
    const result = await executor.undo(undo_handle);

    console.log(
      `[ExecutorAdapter] Undo executed: ${result.success ? "success" : "failure"}`
    );

    return result;
  } catch (error) {
    if (error instanceof ExecutorAdapterError) {
      throw error;
    }
    throw new ExecutorAdapterError(
      `Failed to undo action: ${error instanceof Error ? error.message : String(error)}`,
      { original_error: error }
    );
  }
}

/**
 * Get all registered executors
 */
export function getExecutors(): Executor[] {
  return Array.from(executors.values());
}

/**
 * Get executor statistics
 */
export function getExecutorStats(): {
  total_executors: number;
  executors_by_type: Record<string, number>;
} {
  const executors_by_type: Record<string, number> = {};

  for (const executor of Array.from(executors.values())) {
    executors_by_type[executor.executor_type] =
      (executors_by_type[executor.executor_type] || 0) + 1;
  }

  return {
    total_executors: executors.size,
    executors_by_type,
  };
}

// ============================================================================
// HELPER FUNCTIONS
// ============================================================================

/**
 * Find an executor that can handle the given action
 */
function findExecutor(action: ActionSchema): Executor | null {
  for (const executor of Array.from(executors.values())) {
    if (executor.canExecute(action)) {
      return executor;
    }
  }
  return null;
}

/**
 * Check if preconditions are met
 */
async function checkPreconditions(action: ActionSchema): Promise<ExecutionResult> {
  if (!action.preconditions || action.preconditions.length === 0) {
    return { success: true };
  }

  // Check each precondition
  for (const precondition of action.preconditions) {
    const met = await evaluatePrecondition(precondition);
    if (!met) {
      return {
        success: false,
        error: {
          code: "PRECONDITION_FAILED",
          message: `Precondition not met: ${precondition.type}`,
          details: precondition,
        },
      };
    }
  }

  return { success: true };
}

/**
 * Evaluate a single precondition
 */
async function evaluatePrecondition(precondition: any): Promise<boolean> {
  // Stub implementation
  // In a real implementation, this would check the actual state
  
  switch (precondition.type) {
    case "element_exists":
      // Check if element exists in DOM
      return true; // Stub: assume it exists
    case "element_visible":
      // Check if element is visible
      return true; // Stub: assume it's visible
    case "element_enabled":
      // Check if element is enabled
      return true; // Stub: assume it's enabled
    default:
      return true;
  }
}

/**
 * Check if postconditions are met
 */
async function checkPostconditions(
  action: ActionSchema,
  result: ExecutionResult
): Promise<ExecutionResult> {
  if (!action.postconditions || action.postconditions.length === 0) {
    return { success: true };
  }

  // Check each postcondition
  for (const postcondition of action.postconditions) {
    const met = await evaluatePostcondition(postcondition, result);
    if (!met) {
      return {
        success: false,
        error: {
          code: "POSTCONDITION_FAILED",
          message: `Postcondition not met: ${postcondition.type}`,
          details: postcondition,
        },
      };
    }
  }

  return { success: true };
}

/**
 * Evaluate a single postcondition
 */
async function evaluatePostcondition(
  postcondition: any,
  result: ExecutionResult
): Promise<boolean> {
  // Stub implementation
  // In a real implementation, this would verify the actual result
  
  switch (postcondition.type) {
    case "element_value_changed":
      // Check if element value changed
      return true; // Stub: assume it changed
    case "element_created":
      // Check if element was created
      return true; // Stub: assume it was created
    case "api_response_success":
      // Check if API response was successful
      return result.success;
    default:
      return true;
  }
}

/**
 * Generate execution receipts (logs, artifacts, screenshots)
 */
async function generateReceipts(
  action: ActionSchema,
  result: ExecutionResult,
  executor: Executor
): Promise<{
  log_entries: string[];
  artifact_ids: string[];
  screenshots?: string[];
}> {
  const log_entries: string[] = [];
  const artifact_ids: string[] = [];

  // Log the execution
  log_entries.push(
    `[${new Date().toISOString()}] Executed ${action.operation} on ${action.target} via ${executor.executor_id}: ${result.success ? "success" : "failure"}`
  );

  // Log to provenance
  try {
    const provenance = await logProvenance({
      artifact_type: "state_change",
      content_hash: generateContentHash(action, result),
      produced_by: {
        agent_id: executor.executor_id,
      },
      policy_regime: {
        constitution_version: "1.0.0",
      },
      executor: executor.executor_id,
      timestamps: {
        created_at: new Date().toISOString(),
        executed_at: new Date().toISOString(),
      },
    });

    artifact_ids.push(provenance.artifact_id);
  } catch (error) {
    console.error("[ExecutorAdapter] Failed to log provenance:", error);
  }

  return {
    log_entries,
    artifact_ids,
  };
}

/**
 * Generate undo handle for reversible actions
 */
async function generateUndoHandle(
  action: ActionSchema,
  executor: Executor
): Promise<string> {
  // Encode executor ID and action info in the handle
  const handle_data = {
    executor_id: executor.executor_id,
    action_info: {
      operation: action.operation,
      target: action.target,
      parameters: action.parameters,
      idempotency_key: action.idempotency_key,
    },
    created_at: new Date().toISOString(),
  };

  // In a real implementation, this would be stored securely
  return Buffer.from(JSON.stringify(handle_data)).toString("base64");
}

/**
 * Parse undo handle to extract executor and action info
 */
function parseUndoHandle(undo_handle: string): {
  executor_id: string;
  action_info: any;
} {
  try {
    const decoded = Buffer.from(undo_handle, "base64").toString("utf-8");
    const data = JSON.parse(decoded);
    return {
      executor_id: data.executor_id,
      action_info: data.action_info,
    };
  } catch (error) {
    throw new ExecutorAdapterError("Invalid undo handle", { undo_handle });
  }
}

/**
 * Generate content hash for action and result
 */
function generateContentHash(action: ActionSchema, result: ExecutionResult): string {
  const crypto = require("crypto");
  const data = JSON.stringify({ action, result });
  return crypto.createHash("sha256").update(data).digest("hex");
}

/**
 * Clear all executors (useful for testing)
 */
export function clearExecutors(): void {
  executors.clear();
  console.log("[ExecutorAdapter] Cleared all executors");
}
