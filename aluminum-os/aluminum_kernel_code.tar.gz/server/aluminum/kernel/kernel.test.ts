/**
 * Aluminum Kernel Tests
 * 
 * Comprehensive test suite for all five kernel APIs
 */

import { describe, it, expect, beforeEach } from "vitest";
import { routeIntent } from "./intent-routing";
import { checkPolicy, addConstitutionalRule, clearConstitutionalRules } from "./policy-kernel";
import { logProvenance, getProvenanceRecord, clearProvenanceRecords } from "./provenance";
import { branch, merge, diff, revert, clearVersionControl } from "./version-control";
import { executeAction, registerExecutor, clearExecutors, type Executor } from "./executor-adapter";
import { pluginRegistry, type Plugin } from "../utils/plugin-registry";

// ============================================================================
// INTENT ROUTING API TESTS
// ============================================================================

describe("Intent Routing API", () => {
  beforeEach(() => {
    pluginRegistry.clear();
  });

  it("should route intent to registered plugin", async () => {
    // Register a test plugin
    const testPlugin: Plugin = {
      descriptor: {
        plugin_id: "test_plugin",
        plugin_name: "Test Plugin",
        plugin_version: "1.0.0",
        capabilities: ["send_message"],
        executor_type: "api",
      },
      canHandle: async (intent) => ({
        can_handle: true,
        score: 0.9,
      }),
      handle: async (intent) => ({
        plan: [
          {
            step_id: "step_1",
            action_schema: {
              target: "gmail",
              operation: "send_message",
              parameters: {},
            },
          },
        ],
        estimated_duration: 5000,
        required_permissions: [],
      }),
    };

    pluginRegistry.register(testPlugin);

    const result = await routeIntent({
      intent_text: "Send an email to John",
      context_snapshot: {},
      constraints: {
        risk_level: "low",
      },
    });

    expect(result.selected_agent).toBe("test_plugin");
    expect(result.plan).toHaveLength(1);
    expect(result.confidence).toBe(0.9);
  });

  it("should throw error when no plugins available", async () => {
    await expect(
      routeIntent({
        intent_text: "Send an email",
        context_snapshot: {},
        constraints: { risk_level: "low" },
      })
    ).rejects.toThrow("No plugins available");
  });
});

// ============================================================================
// POLICY KERNEL API TESTS
// ============================================================================

describe("Policy Kernel API", () => {
  beforeEach(() => {
    clearConstitutionalRules();
  });

  it("should allow actions that don't trigger rules", async () => {
    const result = await checkPolicy({
      plan: [
        {
          step_id: "step_1",
          action_schema: {
            target: "file",
            operation: "read",
            parameters: {},
          },
        },
      ],
      context: {
        user_id: "user_123",
        device_id: "device_456",
      },
      policy_version: "1.0.0",
    });

    expect(result.decision).toBe("allow");
  });

  it("should require approval for sensitive actions", async () => {
    addConstitutionalRule({
      rule_text: "Require approval for file deletion",
      rule_type: "require_approval",
      priority: 90,
      conditions: [
        { field: "operation", operator: "equals", value: "delete" },
      ],
    });

    const result = await checkPolicy({
      plan: [
        {
          step_id: "step_1",
          action_schema: {
            target: "file",
            operation: "delete",
            parameters: {},
          },
        },
      ],
      context: {
        user_id: "user_123",
        device_id: "device_456",
      },
      policy_version: "1.0.0",
    });

    expect(result.decision).toBe("requires_approval");
    expect(result.required_approvals).toBeDefined();
    expect(result.required_approvals).toHaveLength(1);
  });

  it("should block prohibited actions", async () => {
    addConstitutionalRule({
      rule_text: "Block all admin operations",
      rule_type: "block",
      priority: 100,
      conditions: [
        { field: "target", operator: "equals", value: "admin" },
      ],
    });

    const result = await checkPolicy({
      plan: [
        {
          step_id: "step_1",
          action_schema: {
            target: "admin",
            operation: "modify",
            parameters: {},
          },
        },
      ],
      context: {
        user_id: "user_123",
        device_id: "device_456",
      },
      policy_version: "1.0.0",
    });

    expect(result.decision).toBe("block");
  });
});

// ============================================================================
// PROVENANCE API TESTS
// ============================================================================

describe("Provenance API", () => {
  beforeEach(() => {
    clearProvenanceRecords();
  });

  it("should log provenance record", async () => {
    const result = await logProvenance({
      artifact_type: "message",
      content_hash: "abc123",
      produced_by: {
        agent_id: "test_agent",
      },
      policy_regime: {
        constitution_version: "1.0.0",
      },
      executor: "test_executor",
      timestamps: {
        created_at: new Date().toISOString(),
      },
    });

    expect(result.artifact_id).toBeDefined();
    expect(result.provenance_record_location).toContain("aluminum://provenance/");
  });

  it("should retrieve provenance record", async () => {
    const logged = await logProvenance({
      artifact_type: "file",
      content_hash: "def456",
      produced_by: {
        agent_id: "test_agent",
      },
      policy_regime: {
        constitution_version: "1.0.0",
      },
      executor: "test_executor",
      timestamps: {
        created_at: new Date().toISOString(),
      },
    });

    const record = await getProvenanceRecord(logged.artifact_id);

    expect(record).toBeDefined();
    expect(record?.artifact_id).toBe(logged.artifact_id);
    expect(record?.artifact_type).toBe("file");
  });

  it("should return null for non-existent artifact", async () => {
    const record = await getProvenanceRecord("nonexistent_id");
    expect(record).toBeNull();
  });
});

// ============================================================================
// VERSION CONTROL API TESTS
// ============================================================================

describe("Version Control API", () => {
  beforeEach(() => {
    clearVersionControl();
  });

  it("should create a branch", async () => {
    // Create initial state
    const initialBranch = await branch({
      target_id: "initial_state",
      label: "Initial",
    });
    
    const result = await branch({
      target_id: initialBranch.new_branch_id,
      label: "Test Branch",
    });

    expect(result.new_branch_id).toBeDefined();
    expect(result.snapshot_id).toBeDefined();
    expect(result.parent_id).toBe(initialBranch.new_branch_id);
  });

  it("should compute diff between states", async () => {
    // Create initial state
    const initial = await branch({
      target_id: "initial_state",
      label: "Initial",
    });
    
    // Create two branches from initial
    const branch1 = await branch({
      target_id: initial.new_branch_id,
      label: "Branch 1",
    });

    const branch2 = await branch({
      target_id: initial.new_branch_id,
      label: "Branch 2",
    });

    const result = await diff({
      a: branch1.snapshot_id,
      b: branch2.snapshot_id,
    });

    expect(result.diff).toBeDefined();
    expect(result.diff.added_elements).toBeDefined();
    expect(result.diff.removed_elements).toBeDefined();
    expect(result.diff.modified_elements).toBeDefined();
  });

  it("should revert to previous snapshot", async () => {
    // Create initial state
    const initial = await branch({
      target_id: "initial_state",
      label: "Initial",
    });
    
    const branchResult = await branch({
      target_id: initial.new_branch_id,
      label: "Checkpoint",
    });

    const result = await revert({
      target_id: "conversation_123",
      snapshot_id: branchResult.snapshot_id,
    });

    expect(result.restored_state).toBe("conversation_123");
    expect(result.reverted_changes).toBeDefined();
  });
});

// ============================================================================
// EXECUTOR ADAPTER API TESTS
// ============================================================================

describe("Executor Adapter API", () => {
  beforeEach(() => {
    clearExecutors();
  });

  it("should execute action with registered executor", async () => {
    // Register a test executor
    const testExecutor: Executor = {
      executor_id: "test_executor",
      executor_type: "api",
      canExecute: (action) => action.target === "test_target",
      execute: async (action) => ({
        success: true,
        data: { message: "Action executed" },
      }),
    };

    registerExecutor(testExecutor);

    const result = await executeAction({
      action_schema: {
        target: "test_target",
        operation: "test_operation",
        parameters: {},
      },
    });

    expect(result.result.success).toBe(true);
    expect(result.receipts.log_entries).toHaveLength(1);
    expect(result.receipts.artifact_ids.length).toBeGreaterThan(0);
  });

  it("should throw error when no executor available", async () => {
    await expect(
      executeAction({
        action_schema: {
          target: "unknown_target",
          operation: "unknown_operation",
          parameters: {},
        },
      })
    ).rejects.toThrow("No executor available");
  });

  it("should support undo for reversible actions", async () => {
    // Register executor with undo support
    const testExecutor: Executor = {
      executor_id: "test_executor",
      executor_type: "api",
      canExecute: (action) => action.target === "test_target",
      execute: async (action) => ({
        success: true,
        data: { message: "Action executed" },
      }),
      undo: async (undo_handle) => ({
        success: true,
        data: { message: "Action undone" },
      }),
    };

    registerExecutor(testExecutor);

    const result = await executeAction({
      action_schema: {
        target: "test_target",
        operation: "test_operation",
        parameters: {},
      },
    });

    expect(result.undo_handle).toBeDefined();
  });
});

// ============================================================================
// INTEGRATION TESTS
// ============================================================================

describe("Kernel Integration", () => {
  beforeEach(() => {
    pluginRegistry.clear();
    clearConstitutionalRules();
    clearProvenanceRecords();
    clearVersionControl();
    clearExecutors();
  });

  it("should complete full workflow: route -> policy -> execute -> provenance", async () => {
    // 1. Register plugin
    const testPlugin: Plugin = {
      descriptor: {
        plugin_id: "test_plugin",
        plugin_name: "Test Plugin",
        plugin_version: "1.0.0",
        capabilities: ["test_action"],
        executor_type: "api",
      },
      canHandle: async () => ({ can_handle: true, score: 0.9 }),
      handle: async () => ({
        plan: [
          {
            step_id: "step_1",
            action_schema: {
              target: "test_target",
              operation: "test_operation",
              parameters: {},
            },
          },
        ],
        estimated_duration: 1000,
        required_permissions: [],
      }),
    };

    pluginRegistry.register(testPlugin);

    // 2. Register executor
    const testExecutor: Executor = {
      executor_id: "test_executor",
      executor_type: "api",
      canExecute: () => true,
      execute: async () => ({ success: true }),
    };

    registerExecutor(testExecutor);

    // 3. Route intent
    const routing = await routeIntent({
      intent_text: "Do a test action",
      context_snapshot: {},
      constraints: { risk_level: "low" },
    });

    expect(routing.selected_agent).toBe("test_plugin");

    // 4. Check policy
    const policy = await checkPolicy({
      plan: routing.plan,
      context: { user_id: "user_123", device_id: "device_456" },
      policy_version: "1.0.0",
    });

    expect(policy.decision).toBe("allow");

    // 5. Execute action
    const execution = await executeAction({
      action_schema: routing.plan[0].action_schema,
    });

    expect(execution.result.success).toBe(true);
    expect(execution.receipts.artifact_ids.length).toBeGreaterThan(0);

    // 6. Verify provenance was logged
    const provenance = await getProvenanceRecord(execution.receipts.artifact_ids[0]);
    expect(provenance).toBeDefined();
  });
});
