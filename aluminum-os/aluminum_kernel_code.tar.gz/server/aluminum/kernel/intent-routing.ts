/**
 * Aluminum Intent Routing API
 * 
 * Determines which agent or plugin should handle a user's intent based on
 * context, capabilities, and constraints.
 * 
 * This is a stub implementation that will be expanded with real NLU and
 * plugin selection logic.
 */

import type {
  IntentRoutingInput,
  IntentRoutingOutput,
} from "../types/kernel";
import { IntentRoutingError } from "../types/kernel";
import { pluginRegistry } from "../utils/plugin-registry";

/**
 * Route an intent to the best available plugin
 * 
 * @param input - Intent text, context, and constraints
 * @returns Selected agent, execution plan, and confidence score
 */
export async function routeIntent(
  input: IntentRoutingInput
): Promise<IntentRoutingOutput> {
  try {
    console.log("[IntentRouting] Routing intent:", input.intent_text);

    // Find candidate plugins that can handle this intent
    const candidates = await pluginRegistry.findCandidates(input);

    if (candidates.length === 0) {
      throw new IntentRoutingError(
        "No plugins available to handle this intent",
        { intent: input.intent_text }
      );
    }

    // Select the best plugin (highest score)
    const bestCandidate = candidates[0];
    const { plugin, score } = bestCandidate;

    console.log(
      `[IntentRouting] Selected plugin: ${plugin.descriptor.plugin_id} (score: ${score.score})`
    );

    // Generate execution plan from the selected plugin
    const plan = await plugin.handle(input);

    // Collect alternative plugins (next 3 best candidates)
    const alternatives = candidates
      .slice(1, 4)
      .map((c) => c.plugin.descriptor.plugin_id);

    return {
      selected_agent: plugin.descriptor.plugin_id,
      plan: plan.plan,
      confidence: score.score,
      alternatives: alternatives.length > 0 ? alternatives : undefined,
    };
  } catch (error) {
    if (error instanceof IntentRoutingError) {
      throw error;
    }
    throw new IntentRoutingError(
      `Failed to route intent: ${error instanceof Error ? error.message : String(error)}`,
      { original_error: error }
    );
  }
}

/**
 * Parse intent text into structured components (stub implementation)
 * 
 * In a real implementation, this would use NLU to extract:
 * - Action verb (send, create, delete, etc.)
 * - Object (email, file, event, etc.)
 * - Parameters (recipient, subject, date, etc.)
 * 
 * For now, this is a simple keyword-based parser.
 */
export function parseIntent(intentText: string): {
  action?: string;
  object?: string;
  parameters?: Record<string, string>;
} {
  const lower = intentText.toLowerCase();

  // Detect action verbs
  let action: string | undefined;
  if (lower.includes("send") || lower.includes("email")) {
    action = "send_message";
  } else if (lower.includes("create") || lower.includes("new")) {
    action = "create";
  } else if (lower.includes("delete") || lower.includes("remove")) {
    action = "delete";
  } else if (lower.includes("search") || lower.includes("find")) {
    action = "search";
  } else if (lower.includes("read") || lower.includes("show")) {
    action = "read";
  }

  // Detect object types
  let object: string | undefined;
  if (lower.includes("email") || lower.includes("message")) {
    object = "message";
  } else if (lower.includes("file") || lower.includes("document")) {
    object = "file";
  } else if (lower.includes("event") || lower.includes("meeting")) {
    object = "event";
  } else if (lower.includes("task") || lower.includes("todo")) {
    object = "task";
  }

  // TODO: Extract parameters using more sophisticated NLU
  const parameters: Record<string, string> = {};

  return { action, object, parameters };
}

/**
 * Estimate intent complexity (stub implementation)
 * 
 * Returns a complexity score from 0-1 based on:
 * - Number of steps required
 * - Number of systems involved
 * - Risk level
 */
export function estimateComplexity(input: IntentRoutingInput): number {
  const parsed = parseIntent(input.intent_text);
  
  let complexity = 0.3; // Base complexity

  // Increase complexity for multi-step actions
  if (parsed.action === "create" || parsed.action === "send_message") {
    complexity += 0.2;
  }

  // Increase complexity based on risk level
  if (input.constraints.risk_level === "high") {
    complexity += 0.3;
  } else if (input.constraints.risk_level === "medium") {
    complexity += 0.1;
  }

  // Increase complexity if time limit is tight
  if (input.constraints.time_limit && input.constraints.time_limit < 10000) {
    complexity += 0.2;
  }

  return Math.min(complexity, 1.0);
}
