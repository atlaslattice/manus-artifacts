/**
 * Aluminum Provenance API
 * 
 * Establishes lineage for every artifact and action, creating an immutable audit trail
 * that enables accountability, debugging, and reversibility.
 * 
 * This is Killer Feature #0 - the foundation of trust in the Aluminum ecosystem.
 */

import type {
  ProvenanceInput,
  ProvenanceOutput,
} from "../types/kernel";
import { ProvenanceError } from "../types/kernel";
import crypto from "crypto";

/**
 * In-memory storage for provenance records
 * In a real implementation, this would be stored in an append-only database
 */
interface ProvenanceRecord extends ProvenanceInput {
  artifact_id: string;
  recorded_at: string;
}

const provenanceRecords: Map<string, ProvenanceRecord> = new Map();

/**
 * Log a provenance record for an artifact or action
 * 
 * @param input - Artifact metadata and lineage
 * @returns Artifact ID and provenance record location
 */
export async function logProvenance(
  input: ProvenanceInput
): Promise<ProvenanceOutput> {
  try {
    // Generate unique artifact ID
    const artifact_id = generateArtifactId(input);

    // Create provenance record
    const record: ProvenanceRecord = {
      ...input,
      artifact_id,
      recorded_at: new Date().toISOString(),
    };

    // Store record (append-only, immutable)
    provenanceRecords.set(artifact_id, record);

    console.log(`[Provenance] Logged artifact: ${artifact_id}`);

    return {
      artifact_id,
      provenance_record_location: `aluminum://provenance/${artifact_id}`,
    };
  } catch (error) {
    throw new ProvenanceError(
      `Failed to log provenance: ${error instanceof Error ? error.message : String(error)}`,
      { original_error: error }
    );
  }
}

/**
 * Retrieve a provenance record by artifact ID
 */
export async function getProvenanceRecord(
  artifact_id: string
): Promise<ProvenanceRecord | null> {
  const record = provenanceRecords.get(artifact_id);
  return record || null;
}

/**
 * Query provenance records by criteria
 */
export async function queryProvenance(criteria: {
  artifact_type?: string;
  produced_by_agent?: string;
  executor?: string;
  start_time?: string;
  end_time?: string;
  parent_id?: string;
}): Promise<ProvenanceRecord[]> {
  const results: ProvenanceRecord[] = [];

  for (const record of Array.from(provenanceRecords.values())) {
    if (criteria.artifact_type && record.artifact_type !== criteria.artifact_type) {
      continue;
    }

    if (criteria.produced_by_agent && record.produced_by.agent_id !== criteria.produced_by_agent) {
      continue;
    }

    if (criteria.executor && record.executor !== criteria.executor) {
      continue;
    }

    if (criteria.start_time && record.timestamps.created_at < criteria.start_time) {
      continue;
    }

    if (criteria.end_time && record.timestamps.created_at > criteria.end_time) {
      continue;
    }

    if (criteria.parent_id && !record.parents?.includes(criteria.parent_id)) {
      continue;
    }

    results.push(record);
  }

  // Sort by creation time (newest first)
  results.sort((a, b) => 
    new Date(b.timestamps.created_at).getTime() - new Date(a.timestamps.created_at).getTime()
  );

  return results;
}

/**
 * Get the full lineage of an artifact (all ancestors)
 */
export async function getLineage(artifact_id: string): Promise<ProvenanceRecord[]> {
  const lineage: ProvenanceRecord[] = [];
  const visited = new Set<string>();

  async function traverse(id: string) {
    if (visited.has(id)) {
      return; // Avoid cycles
    }

    visited.add(id);

    const record = await getProvenanceRecord(id);
    if (!record) {
      return;
    }

    lineage.push(record);

    // Recursively traverse parents
    if (record.parents) {
      for (const parent_id of record.parents) {
        await traverse(parent_id);
      }
    }
  }

  await traverse(artifact_id);

  return lineage;
}

/**
 * Get all descendants of an artifact
 */
export async function getDescendants(artifact_id: string): Promise<ProvenanceRecord[]> {
  const descendants: ProvenanceRecord[] = [];

  for (const record of Array.from(provenanceRecords.values())) {
    if (record.parents?.includes(artifact_id)) {
      descendants.push(record);
    }
  }

  // Sort by creation time (oldest first)
  descendants.sort((a, b) => 
    new Date(a.timestamps.created_at).getTime() - new Date(b.timestamps.created_at).getTime()
  );

  return descendants;
}

/**
 * Verify the integrity of a provenance record
 */
export async function verifyProvenance(artifact_id: string): Promise<{
  valid: boolean;
  issues: string[];
}> {
  const record = await getProvenanceRecord(artifact_id);
  
  if (!record) {
    return {
      valid: false,
      issues: ["Artifact not found"],
    };
  }

  const issues: string[] = [];

  // Check if all parents exist
  if (record.parents) {
    for (const parent_id of record.parents) {
      const parent = await getProvenanceRecord(parent_id);
      if (!parent) {
        issues.push(`Parent artifact ${parent_id} not found`);
      }
    }
  }

  // Check if timestamps are valid
  if (record.timestamps.modified_at && record.timestamps.modified_at < record.timestamps.created_at) {
    issues.push("Modified timestamp is before created timestamp");
  }

  if (record.timestamps.executed_at && record.timestamps.executed_at < record.timestamps.created_at) {
    issues.push("Executed timestamp is before created timestamp");
  }

  // Check if approvals are valid
  if (record.approvals) {
    for (const approval of record.approvals) {
      if (approval.timestamp < record.timestamps.created_at) {
        issues.push(`Approval timestamp ${approval.timestamp} is before artifact creation`);
      }
    }
  }

  return {
    valid: issues.length === 0,
    issues,
  };
}

/**
 * Get provenance statistics
 */
export function getProvenanceStats(): {
  total_records: number;
  records_by_type: Record<string, number>;
  records_by_agent: Record<string, number>;
  records_by_executor: Record<string, number>;
  oldest_record?: string;
  newest_record?: string;
} {
  const records_by_type: Record<string, number> = {};
  const records_by_agent: Record<string, number> = {};
  const records_by_executor: Record<string, number> = {};

  let oldest_record: string | undefined;
  let newest_record: string | undefined;

  for (const record of Array.from(provenanceRecords.values())) {
    // Count by type
    records_by_type[record.artifact_type] = (records_by_type[record.artifact_type] || 0) + 1;

    // Count by agent
    records_by_agent[record.produced_by.agent_id] = (records_by_agent[record.produced_by.agent_id] || 0) + 1;

    // Count by executor
    records_by_executor[record.executor] = (records_by_executor[record.executor] || 0) + 1;

    // Track oldest and newest
    if (!oldest_record || record.timestamps.created_at < oldest_record) {
      oldest_record = record.timestamps.created_at;
    }

    if (!newest_record || record.timestamps.created_at > newest_record) {
      newest_record = record.timestamps.created_at;
    }
  }

  return {
    total_records: provenanceRecords.size,
    records_by_type,
    records_by_agent,
    records_by_executor,
    oldest_record,
    newest_record,
  };
}

/**
 * Generate a unique artifact ID
 */
function generateArtifactId(input: ProvenanceInput): string {
  // Combine content hash, timestamp, and random salt
  const data = `${input.content_hash}:${Date.now()}:${Math.random()}`;
  const hash = crypto.createHash("sha256").update(data).digest("hex");
  return `artifact_${hash.substring(0, 16)}`;
}

/**
 * Clear all provenance records (useful for testing)
 */
export function clearProvenanceRecords(): void {
  provenanceRecords.clear();
  console.log("[Provenance] Cleared all provenance records");
}

/**
 * Export provenance records to JSON (for backup/archival)
 */
export function exportProvenanceRecords(): ProvenanceRecord[] {
  return Array.from(provenanceRecords.values());
}

/**
 * Import provenance records from JSON (for restore)
 */
export function importProvenanceRecords(records: ProvenanceRecord[]): void {
  for (const record of records) {
    provenanceRecords.set(record.artifact_id, record);
  }
  console.log(`[Provenance] Imported ${records.length} provenance records`);
}
