/**
 * Aluminum Policy Kernel API
 * 
 * Determines whether a proposed plan is allowed, requires approval, or must be blocked
 * based on constitutional rules and user preferences.
 * 
 * This is the governance layer that enforces user-defined rules consistently across
 * all plugins and agents.
 */

import type {
  PolicyKernelInput,
  PolicyKernelOutput,
  PolicyDecision,
  ConstitutionalRule,
} from "../types/kernel";
import { PolicyKernelError } from "../types/kernel";

/**
 * In-memory storage for constitutional rules
 * In a real implementation, this would be stored in a database
 */
const constitutionalRules: ConstitutionalRule[] = [
  {
    rule_id: "rule_1",
    rule_text: "Never share location without asking",
    rule_type: "require_approval",
    priority: 100,
    conditions: [
      { field: "operation", operator: "contains", value: "location" },
    ],
    created_at: new Date().toISOString(),
  },
  {
    rule_id: "rule_2",
    rule_text: "Always require approval before spending money",
    rule_type: "require_approval",
    priority: 100,
    conditions: [
      { field: "operation", operator: "contains", value: "payment" },
      { field: "operation", operator: "contains", value: "purchase" },
    ],
    created_at: new Date().toISOString(),
  },
  {
    rule_id: "rule_3",
    rule_text: "Block any action that deletes files older than 30 days",
    rule_type: "block",
    priority: 90,
    conditions: [
      { field: "operation", operator: "equals", value: "delete" },
      { field: "target", operator: "equals", value: "file" },
    ],
    created_at: new Date().toISOString(),
  },
  {
    rule_id: "rule_4",
    rule_text: "Require biometric approval for financial transactions",
    rule_type: "require_approval",
    priority: 100,
    conditions: [
      { field: "operation", operator: "contains", value: "financial" },
    ],
    created_at: new Date().toISOString(),
  },
  {
    rule_id: "rule_5",
    rule_text: "Log all actions that access medical records",
    rule_type: "allow",
    priority: 80,
    conditions: [
      { field: "target", operator: "contains", value: "medical" },
    ],
    created_at: new Date().toISOString(),
  },
  {
    rule_id: "rule_6",
    rule_text: "Require approval before sending emails with attachments",
    rule_type: "require_approval",
    priority: 70,
    conditions: [
      { field: "operation", operator: "equals", value: "send_message" },
      { field: "parameters.attachments", operator: "exists", value: true },
    ],
    created_at: new Date().toISOString(),
  },
  {
    rule_id: "rule_7",
    rule_text: "Allow reading data without approval",
    rule_type: "allow",
    priority: 10,
    conditions: [
      { field: "operation", operator: "equals", value: "read" },
    ],
    created_at: new Date().toISOString(),
  },
];

/**
 * Check if a plan complies with constitutional rules
 * 
 * @param input - Plan, context, and policy version
 * @returns Decision (allow/requires_approval/block) with rationale
 */
export async function checkPolicy(
  input: PolicyKernelInput
): Promise<PolicyKernelOutput> {
  try {
    console.log(`[PolicyKernel] Checking policy for ${input.plan.length} actions`);

    // Evaluate each action in the plan
    const decisions: Array<{
      step_id: string;
      decision: PolicyDecision;
      triggered_rules: ConstitutionalRule[];
    }> = [];

    for (const step of input.plan) {
      const triggered = evaluateAction(step.action_schema, input.context);
      const decision = determineDecision(triggered);
      
      decisions.push({
        step_id: step.step_id,
        decision,
        triggered_rules: triggered,
      });
    }

    // Aggregate decisions: if any action is blocked, block the whole plan
    // If any action requires approval, require approval for the whole plan
    let finalDecision: PolicyDecision = "allow";
    const allTriggeredRules: ConstitutionalRule[] = [];

    for (const d of decisions) {
      allTriggeredRules.push(...d.triggered_rules);
      
      if (d.decision === "block") {
        finalDecision = "block";
        break;
      } else if (d.decision === "requires_approval") {
        finalDecision = "requires_approval";
      }
    }

    // Generate rationale
    const rationale = generateRationale(finalDecision, allTriggeredRules);

    // Determine logging directives
    const logging_directives = determineLoggingDirectives(
      finalDecision,
      allTriggeredRules
    );

    // Generate required approvals if needed
    const required_approvals =
      finalDecision === "requires_approval"
        ? generateRequiredApprovals(input.context, allTriggeredRules)
        : undefined;

    console.log(`[PolicyKernel] Decision: ${finalDecision}`);

    return {
      decision: finalDecision,
      rationale,
      logging_directives,
      required_approvals,
    };
  } catch (error) {
    throw new PolicyKernelError(
      `Failed to check policy: ${error instanceof Error ? error.message : String(error)}`,
      { original_error: error }
    );
  }
}

/**
 * Evaluate a single action against constitutional rules
 */
function evaluateAction(
  action: any,
  context: any
): ConstitutionalRule[] {
  const triggered: ConstitutionalRule[] = [];

  for (const rule of constitutionalRules) {
    if (ruleMatches(rule, action, context)) {
      triggered.push(rule);
    }
  }

  // Sort by priority (highest first)
  triggered.sort((a, b) => b.priority - a.priority);

  return triggered;
}

/**
 * Check if a rule matches an action
 */
function ruleMatches(
  rule: ConstitutionalRule,
  action: any,
  context: any
): boolean {
  if (!rule.conditions || rule.conditions.length === 0) {
    return false;
  }

  // All conditions must match (AND logic)
  for (const condition of rule.conditions) {
    if (!conditionMatches(condition, action, context)) {
      return false;
    }
  }

  return true;
}

/**
 * Check if a single condition matches
 */
function conditionMatches(
  condition: { field: string; operator: string; value: unknown },
  action: any,
  context: any
): boolean {
  // Get the field value from action or context
  const fieldValue = getFieldValue(condition.field, action, context);

  switch (condition.operator) {
    case "equals":
      return fieldValue === condition.value;
    case "contains":
      return (
        typeof fieldValue === "string" &&
        typeof condition.value === "string" &&
        fieldValue.toLowerCase().includes(condition.value.toLowerCase())
      );
    case "exists":
      return fieldValue !== undefined && fieldValue !== null;
    case "greater_than":
      return typeof fieldValue === "number" && fieldValue > (condition.value as number);
    case "less_than":
      return typeof fieldValue === "number" && fieldValue < (condition.value as number);
    default:
      return false;
  }
}

/**
 * Get a field value from action or context using dot notation
 */
function getFieldValue(field: string, action: any, context: any): unknown {
  // Try action first
  const actionValue = getNestedValue(action, field);
  if (actionValue !== undefined) {
    return actionValue;
  }

  // Try context
  return getNestedValue(context, field);
}

/**
 * Get nested value using dot notation (e.g., "parameters.attachments")
 */
function getNestedValue(obj: any, path: string): unknown {
  const parts = path.split(".");
  let current = obj;

  for (const part of parts) {
    if (current === undefined || current === null) {
      return undefined;
    }
    current = current[part];
  }

  return current;
}

/**
 * Determine the final decision based on triggered rules
 */
function determineDecision(
  triggered: ConstitutionalRule[]
): PolicyDecision {
  if (triggered.length === 0) {
    return "allow";
  }

  // Highest priority rule wins
  const highestPriority = triggered[0];
  // Map rule_type to PolicyDecision
  if (highestPriority.rule_type === "require_approval") {
    return "requires_approval";
  }
  return highestPriority.rule_type as PolicyDecision;
}

/**
 * Generate human-readable rationale for the decision
 */
function generateRationale(
  decision: PolicyDecision,
  triggered: ConstitutionalRule[]
): string {
  if (triggered.length === 0) {
    return "No constitutional rules triggered. Action is allowed.";
  }

  const ruleTexts = triggered.map((r) => `"${r.rule_text}"`).join(", ");

  switch (decision) {
    case "allow":
      return `Action is allowed. Triggered rules: ${ruleTexts}`;
    case "requires_approval":
      return `Action requires user approval per constitutional rules: ${ruleTexts}`;
    case "block":
      return `Action is blocked per constitutional rules: ${ruleTexts}`;
  }
}

/**
 * Determine logging directives based on decision and rules
 */
function determineLoggingDirectives(
  decision: PolicyDecision,
  triggered: ConstitutionalRule[]
): {
  log_level: "minimal" | "standard" | "detailed" | "verbose";
  destinations: string[];
  retention_policy: string;
} {
  // Block and require_approval decisions get detailed logging
  const log_level = decision === "allow" ? "standard" : "detailed";

  // Always log to provenance
  const destinations = ["provenance"];

  // Add audit trail for high-priority rules
  if (triggered.some((r) => r.priority >= 90)) {
    destinations.push("audit_trail");
  }

  // Retention policy based on sensitivity
  const retention_policy = triggered.some((r) => r.priority >= 90)
    ? "7_years"
    : "1_year";

  return {
    log_level,
    destinations,
    retention_policy,
  };
}

/**
 * Generate required approvals based on context and rules
 */
function generateRequiredApprovals(
  context: any,
  triggered: ConstitutionalRule[]
): Array<{
  approver_id: string;
  approval_type: string;
  timeout: number;
}> {
  // Check if biometric approval is required
  const requiresBiometric = triggered.some((r) =>
    r.rule_text.toLowerCase().includes("biometric")
  );

  return [
    {
      approver_id: context.user_id,
      approval_type: requiresBiometric ? "biometric" : "explicit_consent",
      timeout: 300000, // 5 minutes
    },
  ];
}

/**
 * Add a new constitutional rule
 */
export function addConstitutionalRule(rule: Omit<ConstitutionalRule, "rule_id" | "created_at">): ConstitutionalRule {
  const newRule: ConstitutionalRule = {
    ...rule,
    rule_id: `rule_${Date.now()}`,
    created_at: new Date().toISOString(),
  };

  constitutionalRules.push(newRule);
  console.log(`[PolicyKernel] Added rule: ${newRule.rule_id}`);

  return newRule;
}

/**
 * Remove a constitutional rule
 */
export function removeConstitutionalRule(rule_id: string): boolean {
  const index = constitutionalRules.findIndex((r) => r.rule_id === rule_id);
  
  if (index !== -1) {
    constitutionalRules.splice(index, 1);
    console.log(`[PolicyKernel] Removed rule: ${rule_id}`);
    return true;
  }

  return false;
}

/**
 * Get all constitutional rules
 */
export function getConstitutionalRules(): ConstitutionalRule[] {
  return [...constitutionalRules];
}

/**
 * Clear all constitutional rules (useful for testing)
 */
export function clearConstitutionalRules(): void {
  constitutionalRules.length = 0;
  console.log("[PolicyKernel] Cleared all constitutional rules");
}
