# Aluminum OS Kernel

## Components

### Substrate Layer
The substrate provides the foundational compute primitives for AI-native operations.

### Nexus Architecture
The nexus connects multiple AI models and provides unified API access.

### Constitutional Layer
Implements governance, reversibility, and ethical boundaries.

## Key Files

- `substrate/core.py` - Core substrate implementation
- `nexus/router.py` - Model routing and load balancing
- `constitutional_layer/governance.py` - Constitutional computing rules
