# AI Integration Layer

## Trinity Council V3 (Aluminum)

Multi-LLM orchestration system for consensus-based decision making.

### Supported Models
- Google Gemini (CORTEX)
- Anthropic Claude (SCRIBE)
- OpenAI GPT (ARCHITECT)
- Microsoft Copilot (ENTERPRISE)

## Pantheon Council

Extended governance system for complex multi-stakeholder decisions.

## Model Adapters

Unified interface for all supported AI models.
